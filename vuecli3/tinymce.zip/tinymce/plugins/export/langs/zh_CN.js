tinymce.addI18n("zh_CN", {
  "Export": "\u8f93\u51fa",
  "PDF": "PDF",
  'Failed to load the "{0}" exporter': '"{0}" \u5bfc\u51fa\u7a0b\u5e8f\u52a0\u8f7d\u5931\u8d25',
  "Failed to export to PDF due to browser limitations": "\u7531\u4e8e\u6d4f\u89c8\u5668\u9650\u5236\uff0c\u65e0\u6cd5\u5bfc\u51fa\u4e3a PDF \u683c\u5f0f"
});