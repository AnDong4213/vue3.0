/*!
 * TinyDrive
 *
 * Copyright 2010-2021 Tiny Technologies, Inc. All rights reserved.
 *
 * Version: 1.4.1-91
 */
!(function () {
  "use strict";
  function d(n) {
    var e = n;
    return {
      get: function () {
        return e;
      },
      set: function (n) {
        e = n;
      }
    };
  }
  function m() {}
  function u(t, r) {
    return function () {
      for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
      return t(r.apply(null, n));
    };
  }
  function l(n) {
    return function () {
      return n;
    };
  }
  function r(n) {
    return n;
  }
  var i = l(!1),
    a = l(!0),
    n = function () {
      return f;
    },
    f = {
      fold: function (n, e) {
        return n();
      },
      is: i,
      isSome: i,
      isNone: a,
      getOr: o,
      getOrThunk: t,
      getOrDie: function (n) {
        throw new Error(n || "error: getOrDie called on none.");
      },
      getOrNull: l(null),
      getOrUndefined: l(void 0),
      or: o,
      orThunk: t,
      map: n,
      each: m,
      bind: n,
      exists: i,
      forall: a,
      filter: n,
      equals: e,
      equals_: e,
      toArray: function () {
        return [];
      },
      toString: l("none()")
    };
  function e(n) {
    return n.isNone();
  }
  function t(n) {
    return n();
  }
  function o(n) {
    return n;
  }
  function c(n) {
    return !(null == n);
  }
  function p(n, e) {
    return (n = n), (e = e), -1 < C.call(n, e);
  }
  function h(n, e) {
    for (var t = 0, r = n.length; t < r; t++) if (e(n[t], t)) return !0;
    return !1;
  }
  function g(n, e) {
    for (var t = n.length, r = new Array(t), o = 0; o < t; o++) {
      var u = n[o];
      r[o] = e(u, o);
    }
    return r;
  }
  function s(n, e) {
    for (var t = 0, r = n.length; t < r; t++) e(n[t], t);
  }
  function v(n, e) {
    for (var t = [], r = 0, o = n.length; r < o; r++) {
      var u = n[r];
      e(u, r) && t.push(u);
    }
    return t;
  }
  function y(n, e, t) {
    return (
      s(n, function (n) {
        t = e(t, n);
      }),
      t
    );
  }
  function b(n, e) {
    return (function (n, e, t) {
      for (var r = 0, o = n.length; r < o; r++) {
        var u = n[r];
        if (e(u, r)) return D.some(u);
        if (t(u, r)) break;
      }
      return D.none();
    })(n, e, i);
  }
  function w(n) {
    for (var e = [], t = 0, r = n.length; t < r; ++t) {
      if (!j(n[t]))
        throw new Error(
          "Arr.flatten item " + t + " was not an array, input: " + n
        );
      B.apply(e, n[t]);
    }
    return e;
  }
  function T(n, e) {
    return w(g(n, e));
  }
  function O(n) {
    return (e = n), (n = 0) <= n && n < e.length ? D.some(e[n]) : D.none();
    var e;
  }
  var x,
    F,
    S,
    E,
    U = function (t) {
      function n() {
        return o;
      }
      function e(n) {
        return n(t);
      }
      var r = l(t),
        o = {
          fold: function (n, e) {
            return e(t);
          },
          is: function (n) {
            return t === n;
          },
          isSome: a,
          isNone: i,
          getOr: r,
          getOrThunk: r,
          getOrDie: r,
          getOrNull: r,
          getOrUndefined: r,
          or: n,
          orThunk: n,
          map: function (n) {
            return U(n(t));
          },
          each: function (n) {
            n(t);
          },
          bind: e,
          exists: e,
          forall: e,
          filter: function (n) {
            return n(t) ? o : f;
          },
          toArray: function () {
            return [t];
          },
          toString: function () {
            return "some(" + t + ")";
          },
          equals: function (n) {
            return n.is(t);
          },
          equals_: function (n, e) {
            return n.fold(i, function (n) {
              return e(t, n);
            });
          }
        };
      return o;
    },
    D = {
      some: U,
      none: n,
      from: function (n) {
        return null == n ? f : U(n);
      }
    },
    _ = function () {
      return (_ =
        Object.assign ||
        function (n) {
          for (var e, t = 1, r = arguments.length; t < r; t++)
            for (var o in (e = arguments[t]))
              Object.prototype.hasOwnProperty.call(e, o) && (n[o] = e[o]);
          return n;
        }).apply(this, arguments);
    },
    R = function (t) {
      return function (n) {
        return (
          (n = typeof (e = n)),
          (null === e
            ? "null"
            : "object" == n &&
              (Array.prototype.isPrototypeOf(e) ||
                (e.constructor && "Array" === e.constructor.name))
            ? "array"
            : "object" == n &&
              (String.prototype.isPrototypeOf(e) ||
                (e.constructor && "String" === e.constructor.name))
            ? "string"
            : n) === t
        );
        var e;
      };
    },
    P = function (e) {
      return function (n) {
        return typeof n === e;
      };
    },
    k = R("string"),
    I = R("object"),
    j = R("array"),
    L = P("boolean"),
    M = P("function"),
    A = P("number"),
    C = Array.prototype.indexOf,
    B = Array.prototype.push,
    N = {},
    z = { exports: N };
  (F = N),
    (S = z),
    (E = x = void 0),
    (function (n) {
      "object" == typeof F && void 0 !== S
        ? (S.exports = n())
        : "function" == typeof x && x.amd
        ? x([], n)
        : (("undefined" != typeof window
            ? window
            : "undefined" != typeof global
            ? global
            : "undefined" != typeof self
            ? self
            : this
          ).EphoxContactWrapper = n());
    })(function () {
      return (function r(o, u, i) {
        function a(e, n) {
          if (!u[e]) {
            if (!o[e]) {
              var t = "function" == typeof E && E;
              if (!n && t) return t(e, !0);
              if (f) return f(e, !0);
              throw (
                (((t = new Error("Cannot find module '" + e + "'")).code =
                  "MODULE_NOT_FOUND"),
                t)
              );
            }
            (t = u[e] = { exports: {} }),
              o[e][0].call(
                t.exports,
                function (n) {
                  return a(o[e][1][n] || n);
                },
                t,
                t.exports,
                r,
                o,
                u,
                i
              );
          }
          return u[e].exports;
        }
        for (var f = "function" == typeof E && E, n = 0; n < i.length; n++)
          a(i[n]);
        return a;
      })(
        {
          1: [
            function (n, e, t) {
              var r,
                o,
                e = (e.exports = {});
              function u() {
                throw new Error("setTimeout has not been defined");
              }
              function i() {
                throw new Error("clearTimeout has not been defined");
              }
              function a(e) {
                if (r === setTimeout) return setTimeout(e, 0);
                if ((r === u || !r) && setTimeout)
                  return (r = setTimeout), setTimeout(e, 0);
                try {
                  return r(e, 0);
                } catch (n) {
                  try {
                    return r.call(null, e, 0);
                  } catch (n) {
                    return r.call(this, e, 0);
                  }
                }
              }
              !(function () {
                try {
                  r = "function" == typeof setTimeout ? setTimeout : u;
                } catch (n) {
                  r = u;
                }
                try {
                  o = "function" == typeof clearTimeout ? clearTimeout : i;
                } catch (n) {
                  o = i;
                }
              })();
              var f,
                c = [],
                s = !1,
                l = -1;
              function d() {
                s &&
                  f &&
                  ((s = !1),
                  f.length ? (c = f.concat(c)) : (l = -1),
                  c.length && m());
              }
              function m() {
                if (!s) {
                  var n = a(d);
                  s = !0;
                  for (var e = c.length; e; ) {
                    for (f = c, c = []; ++l < e; ) f && f[l].run();
                    (l = -1), (e = c.length);
                  }
                  (f = null),
                    (s = !1),
                    (function (e) {
                      if (o === clearTimeout) return clearTimeout(e);
                      if ((o === i || !o) && clearTimeout)
                        return (o = clearTimeout), clearTimeout(e);
                      try {
                        o(e);
                      } catch (n) {
                        try {
                          return o.call(null, e);
                        } catch (n) {
                          return o.call(this, e);
                        }
                      }
                    })(n);
                }
              }
              function p(n, e) {
                (this.fun = n), (this.array = e);
              }
              function h() {}
              (e.nextTick = function (n) {
                var e = new Array(arguments.length - 1);
                if (1 < arguments.length)
                  for (var t = 1; t < arguments.length; t++)
                    e[t - 1] = arguments[t];
                c.push(new p(n, e)), 1 !== c.length || s || a(m);
              }),
                (p.prototype.run = function () {
                  this.fun.apply(null, this.array);
                }),
                (e.title = "browser"),
                (e.browser = !0),
                (e.env = {}),
                (e.argv = []),
                (e.version = ""),
                (e.versions = {}),
                (e.on = h),
                (e.addListener = h),
                (e.once = h),
                (e.off = h),
                (e.removeListener = h),
                (e.removeAllListeners = h),
                (e.emit = h),
                (e.prependListener = h),
                (e.prependOnceListener = h),
                (e.listeners = function (n) {
                  return [];
                }),
                (e.binding = function (n) {
                  throw new Error("process.binding is not supported");
                }),
                (e.cwd = function () {
                  return "/";
                }),
                (e.chdir = function (n) {
                  throw new Error("process.chdir is not supported");
                }),
                (e.umask = function () {
                  return 0;
                });
            },
            {}
          ],
          2: [
            function (n, l, e) {
              !function (e) {
                function r() {}
                function u(n) {
                  if ("object" != typeof this)
                    throw new TypeError("Promises must be constructed via new");
                  if ("function" != typeof n)
                    throw new TypeError("not a function");
                  (this._state = 0),
                    (this._handled = !1),
                    (this._value = void 0),
                    (this._deferreds = []),
                    s(n, this);
                }
                function o(t, r) {
                  for (; 3 === t._state; ) t = t._value;
                  0 !== t._state
                    ? ((t._handled = !0),
                      u._immediateFn(function () {
                        var n,
                          e = 1 === t._state ? r.onFulfilled : r.onRejected;
                        if (null !== e) {
                          try {
                            n = e(t._value);
                          } catch (n) {
                            return void a(r.promise, n);
                          }
                          i(r.promise, n);
                        } else (1 === t._state ? i : a)(r.promise, t._value);
                      }))
                    : t._deferreds.push(r);
                }
                function i(e, n) {
                  try {
                    if (n === e)
                      throw new TypeError(
                        "A promise cannot be resolved with itself."
                      );
                    if (n && ("object" == typeof n || "function" == typeof n)) {
                      var t = n.then;
                      if (n instanceof u)
                        return (e._state = 3), (e._value = n), void f(e);
                      if ("function" == typeof t)
                        return void s(
                          ((r = t),
                          (o = n),
                          function () {
                            r.apply(o, arguments);
                          }),
                          e
                        );
                    }
                    (e._state = 1), (e._value = n), f(e);
                  } catch (n) {
                    a(e, n);
                  }
                  var r, o;
                }
                function a(n, e) {
                  (n._state = 2), (n._value = e), f(n);
                }
                function f(n) {
                  2 === n._state &&
                    0 === n._deferreds.length &&
                    u._immediateFn(function () {
                      n._handled || u._unhandledRejectionFn(n._value);
                    });
                  for (var e = 0, t = n._deferreds.length; e < t; e++)
                    o(n, n._deferreds[e]);
                  n._deferreds = null;
                }
                function c(n, e, t) {
                  (this.onFulfilled = "function" == typeof n ? n : null),
                    (this.onRejected = "function" == typeof e ? e : null),
                    (this.promise = t);
                }
                function s(n, e) {
                  var t = !1;
                  try {
                    n(
                      function (n) {
                        t || ((t = !0), i(e, n));
                      },
                      function (n) {
                        t || ((t = !0), a(e, n));
                      }
                    );
                  } catch (n) {
                    if (t) return;
                    (t = !0), a(e, n);
                  }
                }
                var n, t;
                (n = this),
                  (t = setTimeout),
                  (u.prototype.catch = function (n) {
                    return this.then(null, n);
                  }),
                  (u.prototype.then = function (n, e) {
                    var t = new this.constructor(r);
                    return o(this, new c(n, e, t)), t;
                  }),
                  (u.all = function (n) {
                    var a = Array.prototype.slice.call(n);
                    return new u(function (o, u) {
                      if (0 === a.length) return o([]);
                      var i = a.length;
                      for (var n = 0; n < a.length; n++)
                        !(function e(t, n) {
                          try {
                            if (
                              n &&
                              ("object" == typeof n || "function" == typeof n)
                            ) {
                              var r = n.then;
                              if ("function" == typeof r)
                                return void r.call(
                                  n,
                                  function (n) {
                                    e(t, n);
                                  },
                                  u
                                );
                            }
                            (a[t] = n), 0 == --i && o(a);
                          } catch (n) {
                            u(n);
                          }
                        })(n, a[n]);
                    });
                  }),
                  (u.resolve = function (e) {
                    return e && "object" == typeof e && e.constructor === u
                      ? e
                      : new u(function (n) {
                          n(e);
                        });
                  }),
                  (u.reject = function (t) {
                    return new u(function (n, e) {
                      e(t);
                    });
                  }),
                  (u.race = function (o) {
                    return new u(function (n, e) {
                      for (var t = 0, r = o.length; t < r; t++) o[t].then(n, e);
                    });
                  }),
                  (u._immediateFn =
                    "function" == typeof e
                      ? function (n) {
                          e(n);
                        }
                      : function (n) {
                          t(n, 0);
                        }),
                  (u._unhandledRejectionFn = function (n) {
                    "undefined" != typeof console &&
                      console &&
                      console.warn("Possible Unhandled Promise Rejection:", n);
                  }),
                  (u._setImmediateFn = function (n) {
                    u._immediateFn = n;
                  }),
                  (u._setUnhandledRejectionFn = function (n) {
                    u._unhandledRejectionFn = n;
                  }),
                  void 0 !== l && l.exports
                    ? (l.exports = u)
                    : n.Promise || (n.Promise = u);
              }.call(this, n("timers").setImmediate);
            },
            { timers: 3 }
          ],
          3: [
            function (f, n, c) {
              !function (n, e) {
                var r = f("process/browser.js").nextTick,
                  t = Function.prototype.apply,
                  o = Array.prototype.slice,
                  u = {},
                  i = 0;
                function a(n, e) {
                  (this._id = n), (this._clearFn = e);
                }
                (c.setTimeout = function () {
                  return new a(
                    t.call(setTimeout, window, arguments),
                    clearTimeout
                  );
                }),
                  (c.setInterval = function () {
                    return new a(
                      t.call(setInterval, window, arguments),
                      clearInterval
                    );
                  }),
                  (c.clearTimeout = c.clearInterval =
                    function (n) {
                      n.close();
                    }),
                  (a.prototype.unref = a.prototype.ref = function () {}),
                  (a.prototype.close = function () {
                    this._clearFn.call(window, this._id);
                  }),
                  (c.enroll = function (n, e) {
                    clearTimeout(n._idleTimeoutId), (n._idleTimeout = e);
                  }),
                  (c.unenroll = function (n) {
                    clearTimeout(n._idleTimeoutId), (n._idleTimeout = -1);
                  }),
                  (c._unrefActive = c.active =
                    function (n) {
                      clearTimeout(n._idleTimeoutId);
                      var e = n._idleTimeout;
                      0 <= e &&
                        (n._idleTimeoutId = setTimeout(function () {
                          n._onTimeout && n._onTimeout();
                        }, e));
                    }),
                  (c.setImmediate =
                    "function" == typeof n
                      ? n
                      : function (n) {
                          var e = i++,
                            t = !(arguments.length < 2) && o.call(arguments, 1);
                          return (
                            (u[e] = !0),
                            r(function () {
                              u[e] &&
                                (t ? n.apply(null, t) : n.call(null),
                                c.clearImmediate(e));
                            }),
                            e
                          );
                        }),
                  (c.clearImmediate =
                    "function" == typeof e
                      ? e
                      : function (n) {
                          delete u[n];
                        });
              }.call(
                this,
                f("timers").setImmediate,
                f("timers").clearImmediate
              );
            },
            { "process/browser.js": 1, timers: 3 }
          ],
          4: [
            function (n, e, t) {
              var r = n("promise-polyfill"),
                n =
                  "undefined" != typeof window
                    ? window
                    : Function("return this;")();
              e.exports = { boltExport: n.Promise || r };
            },
            { "promise-polyfill": 2 }
          ]
        },
        {},
        [4]
      )(4);
    });
  function G(n) {
    setTimeout(function () {
      throw n;
    }, 0);
  }
  function J(n) {
    return Un(On(n));
  }
  function V(n, e) {
    return (function (n, e) {
      for (var t = null != e ? e : Rn, r = 0; r < n.length && null != t; ++r)
        t = t[n[r]];
      return t;
    })(n.split("."), e);
  }
  function q(i, n) {
    return n(function (r) {
      var o = [],
        u = 0;
      0 === i.length
        ? r([])
        : s(i, function (n, e) {
            var t;
            n.get(
              ((t = e),
              function (n) {
                (o[t] = n), ++u >= i.length && r(o);
              })
            );
          });
    });
  }
  function H(n, e) {
    for (var t = Pn(n), r = 0, o = t.length; r < o; r++) {
      var u = t[r];
      e(n[u], u);
    }
  }
  function W(n, t) {
    return In(n, function (n, e) {
      return { k: e, v: t(n, e) };
    });
  }
  function K(t) {
    return function (n, e) {
      t[e] = n;
    };
  }
  function X(n, e) {
    var t,
      r,
      o,
      u = {},
      i = {};
    return (
      (t = e),
      (r = K(u)),
      (o = K(i)),
      H(n, function (n, e) {
        (t(n, e) ? r : o)(n, e);
      }),
      { t: u, f: i }
    );
  }
  function Y(n, t) {
    var r = [];
    return (
      H(n, function (n, e) {
        r.push(t(n, e));
      }),
      r
    );
  }
  function $(n, e) {
    return Ln(n, e) ? D.from(n[e]) : D.none();
  }
  function Z(n, e) {
    var t = String(e).toLowerCase();
    return b(n, function (n) {
      return n.search(t);
    });
  }
  function Q(n, e) {
    return -1 !== n.indexOf(e);
  }
  function nn(n) {
    return window.matchMedia(n).matches;
  }
  function en(n, e) {
    n.dom.appendChild(e.dom);
  }
  function tn(n, e) {
    var t = n.dom;
    H(e, function (n, e) {
      !(function (n, e, t) {
        if (!(k(t) || L(t) || A(t)))
          throw (
            (console.error(
              "Invalid call to Attribute.set. Key ",
              e,
              ":: Value ",
              t,
              ":: Element ",
              n
            ),
            new Error("Attribute value was not simple"))
          );
        n.setAttribute(e, t + "");
      })(t, e, n);
    });
  }
  function rn(n) {
    function e() {
      return n.stopPropagation();
    }
    function t() {
      return n.preventDefault();
    }
    var r = An.fromDom(
        (function (n) {
          if (oe() && c(n.target)) {
            var e = An.fromDom(n.target);
            if (re(e) && ue(e) && n.composed && n.composedPath) {
              e = n.composedPath();
              if (e) return O(e);
            }
          }
          return D.from(n.target);
        })(n).getOr(n.target)
      ),
      o = u(t, e);
    return {
      target: r,
      x: n.clientX,
      y: n.clientY,
      stop: e,
      prevent: t,
      kill: o,
      raw: n
    };
  }
  function on(n, e, t, r, o) {
    var u,
      i,
      r =
        ((u = t),
        (i = r),
        function (n) {
          u(n) && i(rn(n));
        });
    return (
      n.dom.addEventListener(e, r, o),
      {
        unbind: (function (r) {
          for (var o = [], n = 1; n < arguments.length; n++)
            o[n - 1] = arguments[n];
          return function () {
            for (var n = [], e = 0; e < arguments.length; e++)
              n[e] = arguments[e];
            var t = o.concat(n);
            return r.apply(null, t);
          };
        })(ae, n, e, r, o)
      }
    );
  }
  function un(n, e, t) {
    return on(n, e, fe, t, !1);
  }
  function an(t, r) {
    return _n.nu(function (n) {
      var e = An.fromTag("script");
      tn(e, _({ src: t }, r)),
        un(e, "load", function () {
          n(En.value(e));
        }),
        un(e, "error", function () {
          n(En.error("Failed to load script: " + t));
        }),
        en(ie(An.fromDom(document)), e);
    });
  }
  function fn(n, r, o) {
    return $(n, r).fold(function () {
      return (
        (e = n),
        (t = r),
        an(o, {}).bindResult(function (n) {
          return En.fromOption(
            $(e, t),
            'Could not find "' + t + '" in the given namespace'
          );
        })
      );
      var e, t;
    }, _n.pure);
  }
  function cn(n) {
    var e = v(n, function (n) {
      return n.isError();
    });
    return (0 < e.length ? e : n)[0];
  }
  function sn(n) {
    return (
      (n = [
        fn(
          $(Rn, "tinymce")
            .or($(Rn, "tinydrive"))
            .getOrThunk(function () {
              var n = {};
              return (Rn.tinydrive = n);
            }),
          "_assetManagerProvider",
          n.js
        ),
        ((t = n.css),
        _n.nu(function (n) {
          var e = An.fromTag("link");
          tn(e, { rel: "stylesheet", href: t }),
            un(e, "load", function () {
              n(En.value(e));
            }),
            un(e, "error", function () {
              n(En.error("Failed to load css: " + t));
            }),
            en(An.fromDom(document.head), e);
        }))
      ]),
      q(n, On).map(cn).toLazy()
    );
    var t;
  }
  function ln(n) {
    return n < 10 ? "0" + n.toString() : n.toString();
  }
  function dn(n) {
    return (
      (e = new Date()),
      (t = n),
      (r = e.getFullYear()),
      (n = ln(e.getMonth() + 1)),
      (e = ln(e.getDate())),
      (e = "" + r + n + e),
      t.replace(/\/$/, "") + "/" + e.replace(/^\//, "")
    );
    var e, t, r;
  }
  var mn,
    pn,
    hn,
    gn,
    vn,
    yn = z.exports.boltExport,
    bn = function (n) {
      var t = D.none(),
        e = [],
        r = function (n) {
          o() ? i(n) : e.push(n);
        },
        o = function () {
          return t.isSome();
        },
        u = function (n) {
          s(n, i);
        },
        i = function (e) {
          t.each(function (n) {
            setTimeout(function () {
              e(n);
            }, 0);
          });
        };
      return (
        n(function (n) {
          o() || ((t = D.some(n)), u(e), (e = []));
        }),
        {
          get: r,
          map: function (t) {
            return bn(function (e) {
              r(function (n) {
                e(t(n));
              });
            });
          },
          isReady: o
        }
      );
    },
    wn = {
      nu: bn,
      pure: function (e) {
        return bn(function (n) {
          n(e);
        });
      }
    },
    Tn = function (t) {
      function n(n) {
        t().then(n, G);
      }
      return {
        map: function (n) {
          return Tn(function () {
            return t().then(n);
          });
        },
        bind: function (e) {
          return Tn(function () {
            return t().then(function (n) {
              return e(n).toPromise();
            });
          });
        },
        anonBind: function (n) {
          return Tn(function () {
            return t().then(function () {
              return n.toPromise();
            });
          });
        },
        toLazy: function () {
          return wn.nu(n);
        },
        toCached: function () {
          var n = null;
          return Tn(function () {
            return (n = null === n ? t() : n);
          });
        },
        toPromise: t,
        get: n
      };
    },
    On = function (n) {
      return Tn(function () {
        return new yn(n);
      });
    },
    xn = function (n) {
      return Tn(function () {
        return yn.resolve(n);
      });
    },
    Fn = function (t) {
      return {
        is: function (n) {
          return t === n;
        },
        isValue: a,
        isError: i,
        getOr: l(t),
        getOrThunk: l(t),
        getOrDie: l(t),
        or: function (n) {
          return Fn(t);
        },
        orThunk: function (n) {
          return Fn(t);
        },
        fold: function (n, e) {
          return e(t);
        },
        map: function (n) {
          return Fn(n(t));
        },
        mapError: function (n) {
          return Fn(t);
        },
        each: function (n) {
          n(t);
        },
        bind: function (n) {
          return n(t);
        },
        exists: function (n) {
          return n(t);
        },
        forall: function (n) {
          return n(t);
        },
        toOptional: function () {
          return D.some(t);
        }
      };
    },
    Sn = function (t) {
      return {
        is: i,
        isValue: i,
        isError: a,
        getOr: r,
        getOrThunk: function (n) {
          return n();
        },
        getOrDie: function () {
          return (
            (n = String(t)),
            (function () {
              throw new Error(n);
            })()
          );
          var n;
        },
        or: function (n) {
          return n;
        },
        orThunk: function (n) {
          return n();
        },
        fold: function (n, e) {
          return n(t);
        },
        map: function (n) {
          return Sn(t);
        },
        mapError: function (n) {
          return Sn(n(t));
        },
        each: m,
        bind: function (n) {
          return Sn(t);
        },
        exists: i,
        forall: a,
        toOptional: D.none
      };
    },
    En = {
      value: Fn,
      error: Sn,
      fromOption: function (n, e) {
        return n.fold(function () {
          return Sn(e);
        }, Fn);
      }
    },
    Un = function (u) {
      return _(_({}, u), {
        toCached: function () {
          return Un(u.toCached());
        },
        bindFuture: function (e) {
          return Un(
            u.bind(function (n) {
              return n.fold(
                function (n) {
                  return xn(En.error(n));
                },
                function (n) {
                  return e(n);
                }
              );
            })
          );
        },
        bindResult: function (e) {
          return Un(
            u.map(function (n) {
              return n.bind(e);
            })
          );
        },
        mapResult: function (e) {
          return Un(
            u.map(function (n) {
              return n.map(e);
            })
          );
        },
        mapError: function (e) {
          return Un(
            u.map(function (n) {
              return n.mapError(e);
            })
          );
        },
        foldResult: function (e, t) {
          return u.map(function (n) {
            return n.fold(e, t);
          });
        },
        withTimeout: function (n, o) {
          return Un(
            On(function (e) {
              var t = !1,
                r = setTimeout(function () {
                  (t = !0), e(En.error(o()));
                }, n);
              u.get(function (n) {
                t || (clearTimeout(r), e(n));
              });
            })
          );
        }
      });
    },
    Dn = function (n) {
      return Un(xn(En.value(n)));
    },
    _n = {
      nu: J,
      wrap: Un,
      pure: Dn,
      value: Dn,
      error: function (n) {
        return Un(xn(En.error(n)));
      },
      fromResult: function (n) {
        return Un(xn(n));
      },
      fromFuture: function (n) {
        return Un(n.map(En.value));
      },
      fromPromise: function (n) {
        return J(function (e) {
          n.then(
            function (n) {
              e(En.value(n));
            },
            function (n) {
              e(En.error(n));
            }
          );
        });
      }
    },
    Rn = "undefined" != typeof window ? window : Function("return this;")(),
    Pn = Object.keys,
    kn = Object.hasOwnProperty,
    In = function (n, t) {
      var r = {};
      return (
        H(n, function (n, e) {
          e = t(n, e);
          r[e.k] = e.v;
        }),
        r
      );
    },
    jn = function (n) {
      return Y(n, function (n) {
        return n;
      });
    },
    Ln = function (n, e) {
      return kn.call(n, e);
    },
    Mn = function (n) {
      if (null == n) throw new Error("Node cannot be null or undefined");
      return { dom: n };
    },
    An = {
      fromHtml: function (n, e) {
        e = (e || document).createElement("div");
        if (((e.innerHTML = n), !e.hasChildNodes() || 1 < e.childNodes.length))
          throw (
            (console.error("HTML does not have a single root node", n),
            new Error("HTML must have a single root node"))
          );
        return Mn(e.childNodes[0]);
      },
      fromTag: function (n, e) {
        n = (e || document).createElement(n);
        return Mn(n);
      },
      fromText: function (n, e) {
        n = (e || document).createTextNode(n);
        return Mn(n);
      },
      fromDom: Mn,
      fromPoint: function (n, e, t) {
        return D.from(n.dom.elementFromPoint(e, t)).map(Mn);
      }
    },
    Cn = function () {
      return Bn(0, 0);
    },
    Bn = function (n, e) {
      return { major: n, minor: e };
    },
    Nn = {
      nu: Bn,
      detect: function (n, e) {
        e = String(e).toLowerCase();
        return 0 === n.length
          ? Cn()
          : (function (n, e) {
              var t = (function (n, e) {
                for (var t = 0; t < n.length; t++) {
                  var r = n[t];
                  if (r.test(e)) return r;
                }
              })(n, e);
              if (!t) return { major: 0, minor: 0 };
              n = function (n) {
                return Number(e.replace(t, "$" + n));
              };
              return Bn(n(1), n(2));
            })(n, e);
      },
      unknown: Cn
    },
    zn = function (n, t) {
      return Z(n, t).map(function (n) {
        var e = Nn.detect(n.versionRegexes, t);
        return { current: n.name, version: e };
      });
    },
    Gn = function (n, t) {
      return Z(n, t).map(function (n) {
        var e = Nn.detect(n.versionRegexes, t);
        return { current: n.name, version: e };
      });
    },
    Jn = function (n, e) {
      return (
        (t = n),
        (n = 0),
        "" === (e = e) ||
          (t.length >= e.length && t.substr(n, n + e.length) === e)
      );
      var t;
    },
    n = /.*?version\/\ ?([0-9]+)\.([0-9]+).*/,
    R = function (e) {
      return function (n) {
        return Q(n, e);
      };
    },
    P = [
      {
        name: "Edge",
        versionRegexes: [/.*?edge\/ ?([0-9]+)\.([0-9]+)$/],
        search: function (n) {
          return (
            Q(n, "edge/") &&
            Q(n, "chrome") &&
            Q(n, "safari") &&
            Q(n, "applewebkit")
          );
        }
      },
      {
        name: "Chrome",
        versionRegexes: [/.*?chrome\/([0-9]+)\.([0-9]+).*/, n],
        search: function (n) {
          return Q(n, "chrome") && !Q(n, "chromeframe");
        }
      },
      {
        name: "IE",
        versionRegexes: [
          /.*?msie\ ?([0-9]+)\.([0-9]+).*/,
          /.*?rv:([0-9]+)\.([0-9]+).*/
        ],
        search: function (n) {
          return Q(n, "msie") || Q(n, "trident");
        }
      },
      {
        name: "Opera",
        versionRegexes: [n, /.*?opera\/([0-9]+)\.([0-9]+).*/],
        search: R("opera")
      },
      {
        name: "Firefox",
        versionRegexes: [/.*?firefox\/\ ?([0-9]+)\.([0-9]+).*/],
        search: R("firefox")
      },
      {
        name: "Safari",
        versionRegexes: [n, /.*?cpu os ([0-9]+)_([0-9]+).*/],
        search: function (n) {
          return (Q(n, "safari") || Q(n, "mobile/")) && Q(n, "applewebkit");
        }
      }
    ],
    N = [
      {
        name: "Windows",
        search: R("win"),
        versionRegexes: [/.*?windows\ nt\ ?([0-9]+)\.([0-9]+).*/]
      },
      {
        name: "iOS",
        search: function (n) {
          return Q(n, "iphone") || Q(n, "ipad");
        },
        versionRegexes: [
          /.*?version\/\ ?([0-9]+)\.([0-9]+).*/,
          /.*cpu os ([0-9]+)_([0-9]+).*/,
          /.*cpu iphone os ([0-9]+)_([0-9]+).*/
        ]
      },
      {
        name: "Android",
        search: R("android"),
        versionRegexes: [/.*?android\ ?([0-9]+)\.([0-9]+).*/]
      },
      {
        name: "OSX",
        search: R("mac os x"),
        versionRegexes: [/.*?mac\ os\ x\ ?([0-9]+)_([0-9]+).*/]
      },
      { name: "Linux", search: R("linux"), versionRegexes: [] },
      { name: "Solaris", search: R("sunos"), versionRegexes: [] },
      { name: "FreeBSD", search: R("freebsd"), versionRegexes: [] },
      {
        name: "ChromeOS",
        search: R("cros"),
        versionRegexes: [/.*?chrome\/([0-9]+)\.([0-9]+).*/]
      }
    ],
    Vn = { browsers: l(P), oses: l(N) },
    qn = "Firefox",
    Hn = function (n) {
      var e = n.current,
        t = n.version,
        n = function (n) {
          return function () {
            return e === n;
          };
        };
      return {
        current: e,
        version: t,
        isEdge: n("Edge"),
        isChrome: n("Chrome"),
        isIE: n("IE"),
        isOpera: n("Opera"),
        isFirefox: n(qn),
        isSafari: n("Safari")
      };
    },
    Wn = {
      unknown: function () {
        return Hn({ current: void 0, version: Nn.unknown() });
      },
      nu: Hn,
      edge: l("Edge"),
      chrome: l("Chrome"),
      ie: l("IE"),
      opera: l("Opera"),
      firefox: l(qn),
      safari: l("Safari")
    },
    Kn = "Windows",
    Xn = "Android",
    Yn = "Solaris",
    $n = "FreeBSD",
    Zn = "ChromeOS",
    Qn = function (n) {
      var e = n.current,
        t = n.version,
        n = function (n) {
          return function () {
            return e === n;
          };
        };
      return {
        current: e,
        version: t,
        isWindows: n(Kn),
        isiOS: n("iOS"),
        isAndroid: n(Xn),
        isOSX: n("OSX"),
        isLinux: n("Linux"),
        isSolaris: n(Yn),
        isFreeBSD: n($n),
        isChromeOS: n(Zn)
      };
    },
    ne = {
      unknown: function () {
        return Qn({ current: void 0, version: Nn.unknown() });
      },
      nu: Qn,
      windows: l(Kn),
      ios: l("iOS"),
      android: l(Xn),
      linux: l("Linux"),
      osx: l("OSX"),
      solaris: l(Yn),
      freebsd: l($n),
      chromeos: l(Zn)
    },
    ee = function (n, e) {
      var t,
        r,
        o = Vn.browsers(),
        u = Vn.oses(),
        i = zn(o, n).fold(Wn.unknown, Wn.nu),
        a = Gn(u, n).fold(ne.unknown, ne.nu);
      return {
        browser: i,
        os: a,
        deviceType:
          ((t = i),
          (r = n),
          (o = e),
          (i = (u = a).isiOS() && !0 === /ipad/i.test(r)),
          (n = u.isiOS() && !i),
          (e = u.isiOS() || u.isAndroid()),
          (a = e || o("(pointer:coarse)")),
          (o = i || (!n && e && o("(min-device-width:768px)"))),
          (e = n || (e && !o)),
          (r = t.isSafari() && u.isiOS() && !1 === /safari/i.test(r)),
          {
            isiPad: l(i),
            isiPhone: l(n),
            isTablet: l(o),
            isPhone: l(e),
            isTouch: l(a),
            isAndroid: u.isAndroid,
            isiOS: u.isiOS,
            isWebView: l(r),
            isDesktop: l(!e && !o && !r)
          })
      };
    },
    te =
      ((hn = !(mn = function () {
        return ee(navigator.userAgent, nn);
      })),
      function () {
        for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
        return hn || ((hn = !0), (pn = mn.apply(null, n))), pn;
      }),
    re =
      ((gn = 1),
      function (n) {
        return n.dom.nodeType === gn;
      }),
    z = M(Element.prototype.attachShadow) && M(Node.prototype.getRootNode),
    oe = l(z),
    ue = function (n) {
      return c(n.dom.shadowRoot);
    },
    ie = function (n) {
      n = n.dom.body;
      if (null == n) throw new Error("Body is not available yet");
      return An.fromDom(n);
    },
    ae = function (n, e, t, r) {
      n.dom.removeEventListener(e, t, r);
    },
    fe = a;
  ((Dn = vn = vn || {}).JSON = "json"),
    (Dn.Blob = "blob"),
    (Dn.Text = "text"),
    (Dn.FormData = "formdata"),
    (Dn.MultipartFormData = "multipart/form-data");
  function ce(n) {
    return { type: vn.JSON, data: n };
  }
  function se(t) {
    return On(function (e) {
      var n = new FileReader();
      (n.onload = function (n) {
        n = n.target ? n.target.result : "";
        e(n);
      }),
        n.readAsText(t);
    });
  }
  function le(n) {
    try {
      var e = JSON.parse(n);
      return En.value(e);
    } catch (n) {
      return En.error("Response was not JSON.");
    }
  }
  function de(n) {
    return xn(n.response);
  }
  function me(n, e) {
    switch (n) {
      case vn.JSON:
        return le(e.response).fold(function () {
          return de(e);
        }, xn);
      case vn.Blob:
        return (
          (t = e), D.from(t.response).map(se).getOr(xn("no response content"))
        );
      case vn.Text:
      default:
        return de(e);
    }
    var t;
  }
  function pe(n, e) {
    function t() {
      return _n.pure(e.response);
    }
    function r(n) {
      return _n.error({
        message: n,
        status: e.status,
        responseText: e.responseText
      });
    }
    switch (n) {
      case vn.JSON:
        return le(e.response).fold(r, _n.pure);
      case vn.Blob:
      case vn.Text:
        return t();
      default:
        return r("unknown data type");
    }
  }
  function he(n) {
    var e =
        ((o = n.body),
        D.from(o).bind(function (n) {
          switch (n.type) {
            case vn.JSON:
              return D.some("application/json");
            case vn.FormData:
              return D.some("application/x-www-form-urlencoded; charset=UTF-8");
            case vn.MultipartFormData:
              return D.none();
            case vn.Text:
            default:
              return D.some("text/plain");
          }
        })),
      t = !0 === n.credentials ? D.some(!0) : D.none(),
      r =
        (function (n) {
          switch (n) {
            case vn.Blob:
              return "application/octet-stream";
            case vn.JSON:
              return "application/json, text/javascript";
            case vn.Text:
              return "text/plain";
            default:
              return "";
          }
        })(n.responseType) + ", */*; q=0.01",
      o = void 0 !== n.headers ? n.headers : {};
    return {
      contentType: e,
      responseType: (function (n) {
        switch (n) {
          case vn.JSON:
            return D.none();
          case vn.Blob:
            return D.some("blob");
          case vn.Text:
            return D.some("text");
          default:
            return D.none();
        }
      })(n.responseType),
      credentials: t,
      accept: r,
      headers: o,
      progress: M(n.progress) ? D.some(n.progress) : D.none()
    };
  }
  function ge(n) {
    var t = new FormData();
    return (
      H(n, function (n, e) {
        t.append(e, n);
      }),
      t
    );
  }
  function ve(i) {
    return _n.nu(function (r) {
      var t,
        o = new XMLHttpRequest();
      o.open(
        i.method,
        ((t = i.url),
        D.from(i.query)
          .map(function (n) {
            var e = Y(n, function (n, e) {
                return encodeURIComponent(e) + "=" + encodeURIComponent(n);
              }),
              n = Q(t, "?") ? "&" : "?";
            return 0 < e.length ? t + n + e.join("&") : t;
          })
          .getOr(t)),
        !0
      );
      var u,
        n = he(i);
      (u = o),
        (n = n).contentType.each(function (n) {
          return u.setRequestHeader("Content-Type", n);
        }),
        u.setRequestHeader("Accept", n.accept),
        n.credentials.each(function (n) {
          return (u.withCredentials = n);
        }),
        n.responseType.each(function (n) {
          return (u.responseType = n);
        }),
        n.progress.each(function (e) {
          return u.upload.addEventListener("progress", function (n) {
            return e(n.loaded, n.total);
          });
        }),
        H(n.headers, function (n, e) {
          return u.setRequestHeader(e, n);
        });
      function e() {
        var e, n, t;
        (e = i.url),
          (n = i.responseType),
          me(n, (t = o))
            .map(function (n) {
              return {
                message:
                  0 === t.status
                    ? "Unknown HTTP error (possible cross-domain request)"
                    : "Could not load url " + e + ": " + t.statusText,
                status: t.status,
                responseText: n
              };
            })
            .get(function (n) {
              return r(En.error(n));
            });
      }
      (o.onerror = e),
        (o.onload = function () {
          (0 === o.status && !Jn(i.url, "file:")) ||
          o.status < 100 ||
          400 <= o.status
            ? e()
            : pe(i.responseType, o).get(r);
        }),
        (n = i.body),
        D.from(n)
          .map(function (n) {
            return n.type === vn.JSON
              ? JSON.stringify(n.data)
              : n.type === vn.FormData || n.type === vn.MultipartFormData
              ? ge(n.data)
              : n.data;
          })
          .fold(
            function () {
              return o.send();
            },
            function (n) {
              o.send(n);
            }
          );
    });
  }
  function ye() {
    return { type: vn.Text, data: "" };
  }
  function be(n) {
    return ve(_(_({}, n), { method: "post" }));
  }
  function we(n, e, t) {
    return En.error({ message: e, status: n, responseText: t });
  }
  function Te(t, r) {
    return be({ url: t, responseType: vn.JSON, body: ce({}) }).bindResult(
      function (n) {
        return k(n.token)
          ? ((e = n.token), r.set(D.some(e)), En.value(e))
          : ((e = t),
            r.set(D.none()),
            we(
              500,
              'Jwt token provider: "' +
                e +
                '" did not return a "token" string property in it\'s JSON response body.',
              ""
            ));
        var e;
      }
    );
  }
  function Oe(n, t) {
    return _n.nu(function (e) {
      n(
        function (n) {
          t.set(D.some(n.token)), e(En.value(n.token));
        },
        function (n) {
          t.set(D.none()), e(we(0, n, ""));
        }
      );
    });
  }
  function xe(n, e) {
    return k(n)
      ? ((u = n),
        (i = e),
        function (n) {
          return n
            ? Te(u, i)
            : i.get().fold(
                function () {
                  return Te(u, i);
                },
                function (n) {
                  return _n.pure(n);
                }
              );
        })
      : M(n)
      ? ((r = n),
        (o = e),
        function (n) {
          return n
            ? Oe(r, o)
            : o.get().fold(
                function () {
                  return Oe(r, o);
                },
                function (n) {
                  return _n.pure(n);
                }
              );
        })
      : ((t = "Required jwt token provider not defined."),
        function (n) {
          return _n.fromResult(we(0, t, ""));
        });
    var t, r, o, u, i;
  }
  function Fe(n) {
    return p(qe, n);
  }
  function Se(n) {
    return D.from(n.getParam("tinydrive_max_image_dimension", null, "number"));
  }
  function Ee(t, r) {
    return (
      (n = t),
      D.from(n.getParam("tinydrive_css_url", null, "string")).getOrThunk(
        function () {
          var n,
            e =
              ((n = t),
              D.from(n.getParam("tinydrive_skin", null, "string"))
                .orThunk(function () {
                  return (n = t), D.from(n.getParam("skin", null, "string"));
                  var n;
                })
                .filter(Fe)
                .getOr("oxide"));
          return (
            (n = r),
            "oxide" === (e = e)
              ? n + "/assetmanager.min.css"
              : n + "/skins/" + e + ".min.css"
          );
        }
      )
    );
    var n;
  }
  function Ue(n) {
    return n.replace(/\\/g, "/");
  }
  function De(n, t, r) {
    return n.sort(function (n, e) {
      if ("name" === t)
        return "desc" === r
          ? e.name.localeCompare(n.name)
          : n.name.localeCompare(e.name);
      if ("size" === t) return "desc" === r ? e.size - n.size : n.size - e.size;
      (n = n.modificationDate.getTime()), (e = e.modificationDate.getTime());
      return "desc" === r ? e - n : n - e;
    });
  }
  function _e(n, e, t) {
    return (
      (n = (function (n, e) {
        for (var t = [], r = [], o = 0, u = n.length; o < u; o++) {
          var i = n[o];
          (e(i, o) ? t : r).push(i);
        }
        return { pass: t, fail: r };
      })(n, function (n) {
        return "directory" === n.type;
      })),
      De(n.pass, e, t).concat(De(n.fail, e, t))
    );
  }
  function Re(n) {
    return { type: "", message: n };
  }
  function Pe(n) {
    return { type: "", message: n.message };
  }
  function ke() {
    return (
      (n = "file"),
      (e = new Date().getTime()),
      n + "_" + Math.floor(1e9 * Math.random()) + ++Ye + String(e)
    );
    var n, e;
  }
  function Ie(e, t) {
    var n, r, o;
    return ((n = e.files),
    (r = e.parentUuid),
    (o = t),
    b(n, function (t) {
      return r.fold(
        function () {
          return t.parentUuid.isNone() && t.name === o;
        },
        function (e) {
          return t.parentUuid.exists(function (n) {
            return n === e && t.name === o;
          });
        }
      );
    })).fold(
      function () {
        var n = {
          uuid: ke(),
          type: "directory",
          parentUuid: e.parentUuid,
          name: t,
          size: 0,
          modificationDate: new Date(),
          url: D.none(),
          thumbUrl: D.none(),
          starred: !1,
          path: D.none()
        };
        return { files: e.files.concat([n]), parentUuid: D.some(n.uuid) };
      },
      function (n) {
        return { files: e.files, parentUuid: D.some(n.uuid) };
      }
    );
  }
  function je(n, e) {
    return y(
      v(e.split("/"), function (n) {
        return 0 < n.length;
      }),
      Ie,
      { files: n, parentUuid: D.none() }
    );
  }
  function Le(n) {
    return _n.nu(function (e) {
      n()
        .then(function (n) {
          return e(En.value(n));
        })
        .catch(function (n) {
          return e(En.error(n));
        });
    });
  }
  function Me(n) {
    return new yn(function (e, t) {
      n.get(function (n) {
        n.fold(function (n) {
          return t(n);
        }, e);
      });
    });
  }
  function Ae(n) {
    return (
      (n = n),
      D.from(
        /^([0-9]{4})\-([0-9]{2})\-([0-9]{2}) ([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/.exec(
          n
        )
      ).map(function (n) {
        n = Date.parse(
          n[1] +
            "-" +
            n[2] +
            "-" +
            n[3] +
            "T" +
            n[4] +
            ":" +
            n[5] +
            ":" +
            n[6] +
            "Z"
        );
        return new Date(n);
      })
    );
  }
  function Ce(n) {
    return D.from(n.split(".")[1]).map(function (n) {
      return JSON.parse(window.atob(n));
    });
  }
  function Be(n) {
    for (
      var e = [],
        t = function (n) {
          e.push(n);
        },
        r = 0;
      r < n.length;
      r++
    )
      n[r].each(t);
    return e;
  }
  function Ne(n) {
    return n.bind(r);
  }
  function ze(n) {
    var e,
      n = (-1 !== (n = (e = n).lastIndexOf(".")) ? e.substr(n) : "")
        .substring(1)
        .toLowerCase();
    return p($e, n)
      ? D.some("image")
      : p(Ze, n)
      ? D.some("document")
      : p(Qe, n)
      ? D.some("audio")
      : p(nt, n)
      ? D.some("video")
      : p(et, n)
      ? D.some("archive")
      : D.none();
  }
  function Ge(n) {
    switch (n) {
      case "directory":
        return "directory";
      case "document":
        return "document";
      case "audio":
        return "audio";
      case "video":
        return "video";
      case "image":
        return "image";
      case "archive":
        return "archive";
    }
  }
  function Je(n) {
    switch (n) {
      case "directory":
        return D.some("directory");
      case "document":
        return D.some("document");
      case "audio":
        return D.some("audio");
      case "video":
        return D.some("video");
      case "image":
        return D.some("image");
      case "archive":
        return D.some("archive");
      default:
        return D.none();
    }
  }
  var Ve,
    qe = ["oxide", "oxide-dark"],
    He = Object.prototype.hasOwnProperty,
    n = function (i) {
      return function () {
        for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
        if (0 === n.length) throw new Error("Can't merge zero objects");
        for (var t = {}, r = 0; r < n.length; r++) {
          var o,
            u = n[r];
          for (o in u) He.call(u, o) && (t[o] = i(t[o], u[o]));
        }
        return t;
      };
    },
    We = n(function (n, e) {
      return I(n) && I(e) ? We(n, e) : e;
    }),
    Ke = n(function (n, e) {
      return e;
    }),
    Xe = function (n, e) {
      for (var t = [], r = 2; r < arguments.length; r++)
        t[r - 2] = arguments[r];
      e = Ue(n).replace(/\/$/, "") + "/" + Ue(e).replace(/^\//, "");
      return y(t, Xe, e);
    },
    Ye = 0,
    $e = w(
      jn({
        "image/gif": ["gif"],
        "image/jpeg": ["jpeg", "jpg"],
        "image/png": ["png"],
        "image/tiff": ["tif", "tiff"],
        "image/bmp": ["bmp"]
      })
    ),
    Ze = w(
      jn({
        "application/msword": ["doc"],
        "application/vnd.ms-excel": ["xls"],
        "application/vnd.ms-powerpoint": ["ppt", "pps"],
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
          ["docx"],
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
          "xlsx"
        ],
        "application/vnd.openxmlformats-officedocument.presentationml.presentation":
          ["pptx"],
        "application/pdf": ["pdf"],
        "application/rtf": ["rtf"],
        "text/plain": ["txt"],
        "application/x-iwork-keynote-sffkey": ["key"],
        "application/x-iwork-pages-sffpages": ["pages"],
        "application/x-iwork-numbers-sffnumbers": ["numbers"]
      })
    ),
    Qe = w(
      jn({
        "audio/wav": ["wav", "wave"],
        "audio/mpeg": ["mp3"],
        "audio/ogg": ["ogg", "oga", "ogx", "ogm", "spx", "opus"]
      })
    ),
    nt = w(
      jn({
        "video/mp4": ["mp4", "m4v"],
        "video/ogg": ["ogv"],
        "video/webm": ["webm"],
        "video/quicktime": ["mov"]
      })
    ),
    et = w(jn({ "application/zip": ["zip"] }));
  ((R = Ve = Ve || {})[(R.Error = 0)] = "Error"), (R[(R.Value = 1)] = "Value");
  function tt(n, e, t) {
    return n.stype === Ve.Error ? e(n.serror) : t(n.svalue);
  }
  function rt(n) {
    return { stype: Ve.Value, svalue: n };
  }
  function ot(n) {
    return { stype: Ve.Error, serror: n };
  }
  function ut(n) {
    return I(n) && 100 < Pn(n).length
      ? " removed due to size"
      : JSON.stringify(n, null, 2);
  }
  function it(n, e) {
    return st([{ path: n, getErrorInfo: e }]);
  }
  var at = function (n) {
      return tt(n, En.error, En.value);
    },
    ft = rt,
    ct = function (n) {
      var e = [],
        t = [];
      return (
        s(n, function (n) {
          tt(
            n,
            function (n) {
              return t.push(n);
            },
            function (n) {
              return e.push(n);
            }
          );
        }),
        { values: e, errors: t }
      );
    },
    st = ot,
    lt = function (n, e) {
      return n.stype === Ve.Value ? e(n.svalue) : n;
    },
    dt = function (n, e) {
      return n.stype === Ve.Error ? e(n.serror) : n;
    },
    mt = function (n, e) {
      return n.stype === Ve.Value
        ? { stype: Ve.Value, svalue: e(n.svalue) }
        : n;
    },
    pt = function (n, e) {
      return n.stype === Ve.Error
        ? { stype: Ve.Error, serror: e(n.serror) }
        : n;
    },
    P = function (i) {
      if (!j(i)) throw new Error("cases must be an array");
      if (0 === i.length) throw new Error("there must be at least one case");
      var a = [],
        t = {};
      return (
        s(i, function (n, r) {
          var e = Pn(n);
          if (1 !== e.length) throw new Error("one and only one name per case");
          var o = e[0],
            u = n[o];
          if (void 0 !== t[o]) throw new Error("duplicate key detected:" + o);
          if ("cata" === o)
            throw new Error("cannot have a case named cata (sorry)");
          if (!j(u)) throw new Error("case arguments must be an array");
          a.push(o),
            (t[o] = function () {
              for (var t = [], n = 0; n < arguments.length; n++)
                t[n] = arguments[n];
              var e = t.length;
              if (e !== u.length)
                throw new Error(
                  "Wrong number of arguments to case " +
                    o +
                    ". Expected " +
                    u.length +
                    " (" +
                    u +
                    "), got " +
                    e
                );
              return {
                fold: function () {
                  for (var n = [], e = 0; e < arguments.length; e++)
                    n[e] = arguments[e];
                  if (n.length !== i.length)
                    throw new Error(
                      "Wrong number of arguments to fold. Expected " +
                        i.length +
                        ", got " +
                        n.length
                    );
                  return n[r].apply(null, t);
                },
                match: function (n) {
                  var e = Pn(n);
                  if (a.length !== e.length)
                    throw new Error(
                      "Wrong number of arguments to match. Expected: " +
                        a.join(",") +
                        "\nActual: " +
                        e.join(",")
                    );
                  if (
                    !(function (n, e) {
                      for (var t = 0, r = n.length; t < r; ++t)
                        if (!0 !== e(n[t], t)) return !1;
                      return !0;
                    })(a, function (n) {
                      return p(e, n);
                    })
                  )
                    throw new Error(
                      "Not all branches were specified when using match. Specified: " +
                        e.join(", ") +
                        "\nRequired: " +
                        a.join(", ")
                    );
                  return n[o].apply(null, t);
                },
                log: function (n) {
                  console.log(n, {
                    constructors: a,
                    constructor: o,
                    params: t
                  });
                }
              };
            });
        }),
        t
      );
    },
    ht = P([
      { strict: [] },
      { defaultedThunk: ["fallbackThunk"] },
      { asOption: [] },
      { asDefaultedOptionThunk: ["fallbackThunk"] },
      { mergeWithThunk: ["baseThunk"] }
    ]),
    gt = ht.strict,
    vt = ht.asOption;
  P([
    { bothErrors: ["error1", "error2"] },
    { firstError: ["error1", "value2"] },
    { secondError: ["value1", "error2"] },
    { bothValues: ["value1", "value2"] }
  ]);
  function yt(n, e) {
    var t = {};
    return (t[n] = e), t;
  }
  function bt(n) {
    return u(st, w)(n);
  }
  function wt(t, r, o) {
    return $(r, o).fold(function () {
      return (
        (n = o),
        (e = r),
        it(t, function () {
          return (
            'Could not find valid *strict* value for "' + n + '" in ' + ut(e)
          );
        })
      );
      var n, e;
    }, ft);
  }
  function Tt(n, e, t) {
    return (
      (e = $(n, e).fold(function () {
        return t(n);
      }, r)),
      ft(e)
    );
  }
  function Ot(i, a, n, f) {
    return n.fold(
      function (t, e, n, r) {
        function o(n) {
          return (
            (n = r.extract(i.concat([t]), f, n)),
            mt(n, function (n) {
              return yt(e, f(n));
            })
          );
        }
        function u(n) {
          return n.fold(
            function () {
              var n = yt(e, f(D.none()));
              return ft(n);
            },
            function (n) {
              n = r.extract(i.concat([t]), f, n);
              return mt(n, function (n) {
                return yt(e, f(D.some(n)));
              });
            }
          );
        }
        return n.fold(
          function () {
            return lt(wt(i, a, t), o);
          },
          function (n) {
            return lt(Tt(a, t, n), o);
          },
          function () {
            return lt(ft($(a, t)), u);
          },
          function (n) {
            return lt(
              (function (e, n, t) {
                n = $(e, n).map(function (n) {
                  return !0 === n ? t(e) : n;
                });
                return ft(n);
              })(a, t, n),
              u
            );
          },
          function (n) {
            var e = n(a),
              n = mt(Tt(a, t, l({})), function (n) {
                return We(e, n);
              });
            return lt(n, o);
          }
        );
      },
      function (n, e) {
        e = e(a);
        return ft(yt(n, f(e)));
      }
    );
  }
  function xt(r) {
    return {
      extract: function (t, n, e) {
        return dt(r(e, n), function (n) {
          return (
            (e = n),
            it(t, function () {
              return e;
            })
          );
          var e;
        });
      },
      toString: function () {
        return "val";
      }
    };
  }
  function Ft(r) {
    return {
      extract: function (n, e, t) {
        return (function (e, t, n, r) {
          n = g(n, function (n) {
            return Ot(e, t, n, r);
          });
          return Kt(n, {});
        })(n, t, r, e);
      },
      toString: function () {
        return (
          "obj{\n" +
          g(r, function (n) {
            return n.fold(
              function (n, e, t, r) {
                return n + " -> " + r.toString();
              },
              function (n, e) {
                return "state(" + n + ")";
              }
            );
          }).join("\n") +
          "}"
        );
      }
    };
  }
  function St(o) {
    return {
      extract: function (t, r, n) {
        n = g(n, function (n, e) {
          return o.extract(t.concat(["[" + e + "]"]), r, n);
        });
        return Xt(n);
      },
      toString: function () {
        return "array(" + o.toString() + ")";
      }
    };
  }
  function Et(n, e, t) {
    return at(
      (function (n, e, t, r) {
        t = e.extract([n], t, r);
        return pt(t, function (n) {
          return { input: r, errors: n };
        });
      })(n, e, r, t)
    );
  }
  function Ut(n) {
    return (
      "Errors: \n" +
      (function (n) {
        n =
          10 < n.length
            ? n.slice(0, 10).concat([
                {
                  path: [],
                  getErrorInfo: function () {
                    return "... (only showing first ten failures)";
                  }
                }
              ])
            : n;
        return g(n, function (n) {
          return (
            "Failed path: (" + n.path.join(" > ") + ")\n" + n.getErrorInfo()
          );
        });
      })(n.errors).join("\n") +
      "\n\nInput object: " +
      ut(n.input)
    );
  }
  function Dt(n, e) {
    return $t(n, n, gt(), e);
  }
  function _t(n, e, t) {
    return $t(n, n, ((e = e), ht.defaultedThunk(l(e))), t);
  }
  function Rt(n, e) {
    n.set(Ke(n.get(), { files: e }));
  }
  function Pt(n, e) {
    n.set(Ke(n.get(), { meta: Ke(n.get().meta, e) }));
  }
  function kt(a, n) {
    var f = {},
      t = y(
        n,
        function (n, e) {
          var t,
            r = A(e.size) ? ze(e.name).getOr("document") : "directory",
            o = e.size || 0,
            u = k(e.date) ? Ae(e.date).getOr(new Date()) : new Date(),
            i = e.uuid || ke(),
            o = {
              uuid: i,
              type: r,
              parentUuid: D.from(e.parentUuid),
              name: e.name,
              size: o,
              modificationDate: u,
              url: D.from(e.url),
              thumbUrl: D.from(e.thumbUrl),
              starred: !0 === e.starred,
              path: D.none()
            };
          return (
            (f[i] =
              ((t = a),
              (i = (u = e).meta || {}),
              (u = D.from(i.createdBy).orThunk(function () {
                return Ce(t).map(function (n) {
                  return n.name;
                });
              })),
              { description: i.description || "", createdBy: u })),
            (function (n, e, t) {
              e = je(n, e);
              return e.files.concat([Ke(t, { parentUuid: e.parentUuid })]);
            })(n, e.path, o)
          );
        },
        []
      ),
      r = Ce(a)
        .bind(function (n) {
          return Et("claims", tr, n).toOptional();
        })
        .getOr({ name: "", sub: "", root: D.none() });
    return r.root.fold(
      function () {
        return { files: t, meta: f, claims: r, rootUuid: D.none() };
      },
      function (n) {
        var e = je(t, n),
          n = e.parentUuid;
        return { files: e.files, meta: f, claims: r, rootUuid: n };
      }
    );
  }
  function It(n, r) {
    var o = d({
      files: [],
      meta: {},
      claims: { name: "", sub: "", root: D.none() },
      rootUuid: D.none()
    });
    return function () {
      return n
        .jwtTokenFactory(!1)
        .bindFuture(
          ((t = n.requestDelay),
          function (e) {
            return On(function (n) {
              setTimeout(function () {
                n(En.value(e));
              }, t);
            });
          })
        )
        .mapError(Pe)
        .bindFuture(function (e) {
          return r.mapResult(function (n) {
            return 0 < o.get().files.length || o.set(kt(e, n)), o;
          });
        });
      var t;
    };
  }
  function jt(n, e) {
    return n.parentUuid.bind(function (n) {
      return rr(n, e);
    });
  }
  function Lt(n, e) {
    return Ke(n, { path: e });
  }
  function Mt(n, e) {
    return Lt(
      n,
      D.some(
        (function (n, e) {
          for (
            var t = [], r = jt(n, e);
            r.isSome();
            r = r.bind(function (n) {
              return jt(n, e);
            })
          )
            r.each(function (n) {
              return t.push(n);
            });
          return (
            "/" +
            g(t.reverse(), function (n) {
              return n.name;
            })
              .concat([n.name])
              .join("/")
          );
        })(n, e)
      )
    );
  }
  function At(n, e) {
    return n.query.fold(a, function (n) {
      return -1 !== e.name.toLowerCase().indexOf(n.toLowerCase());
    });
  }
  function Ct(n, e) {
    return (
      0 === n.fileTypes.length ||
      h(n.fileTypes, function (n) {
        return n === e.type;
      })
    );
  }
  function Bt(u, i, a, f, n) {
    return _n.nu(function (r) {
      var o = n.or(u.get().rootUuid);
      ze(a).fold(
        function () {
          return r(
            En.error({
              type: "",
              message: 'Invalid file extension for "' + a + '"'
            })
          );
        },
        function (n) {
          var e = ke(),
            t = {
              uuid: e,
              type: n,
              parentUuid: o,
              name: a,
              size: i.size,
              modificationDate: new Date(),
              url: D.some(URL.createObjectURL(i)),
              thumbUrl: f.map(function (n) {
                return URL.createObjectURL(n);
              }),
              starred: !1,
              path: D.none()
            };
          Pt(
            u,
            (((n = {})[e] = {
              description: "",
              createdBy: D.some(u.get().claims.name)
            }),
            n)
          ),
            Rt(u, u.get().files.concat([t])),
            r(En.value(t));
        }
      );
    });
  }
  function Nt(a) {
    return function (i) {
      return _n.nu(function (n) {
        var t, r, e, o, u;
        (t = function (n, e) {
          e = Math.round(i.size * (n / e));
          a({ name: i.name, uuid: i.uuid, loaded: e, total: i.size });
        }),
          (r = function () {
            n(En.value(i));
          }),
          (o = e = 10),
          (u = function (n, e) {
            setTimeout(function () {
              e < n ? (t(e, n), u(n, e + 1)) : (t(e, n), r());
            }, o);
          })(e, 0);
      });
    };
  }
  function zt(n, e) {
    var t,
      r = je(
        n.get().files,
        ((t = e),
        n
          .get()
          .claims.root.map(function (n) {
            return Xe(n, t.path);
          })
          .getOr(t.path))
      );
    return (
      Rt(n, r.files),
      Bt(n, e.blob, e.name, e.thumbBlob, r.parentUuid).bindFuture(
        Nt(e.progress)
      )
    );
  }
  function Gt(a, n) {
    function u(n, t, r) {
      var e = D.from(n.get().meta[t]).fold(
        function () {
          var n = {};
          return (n[t] = _({ description: "", createdBy: D.none() }, r)), n;
        },
        function (n) {
          var e = {};
          return (e[t] = Ke(n, r)), e;
        }
      );
      Pt(n, Ke(n.get().meta, e));
    }
    function f(n, e) {
      return n.claims.root
        .map(function (t) {
          return e.path.exists(function (n) {
            return t === n || ((e = t), 0 === Xe(n, "/").indexOf(Xe(e, "/")));
            var e;
          });
        })
        .getOr(!0);
    }
    var t,
      r,
      c =
        ((t = It(a, n)),
        (r = a),
        function (e) {
          return t().mapResult(function (n) {
            return r.log && console.log("memfs:", e, n.get().claims), n;
          });
        }),
      s = function (n, e) {
        return g(n, function (n) {
          return e.fold(l(n), function (r) {
            return Lt(
              n,
              n.path.map(function (n) {
                var e, t;
                return (
                  "/" +
                  (Jn((e = n), (t = r + "/"))
                    ? ((n = e), (t = t.length), n.substring(t))
                    : e)
                );
              })
            );
          });
        });
      };
    return {
      rename: function (o, u) {
        return c("rename").bindFuture(function (r) {
          return _n.nu(function (e) {
            var n, t;
            Rt(
              r,
              g(r.get().files, function (n) {
                return n.uuid === o ? Ke(n, { name: u }) : n;
              })
            ),
              O(
                ((n = r.get().files),
                (t = [o]),
                v(n, function (n) {
                  return p(t, n.uuid);
                }))
              ).fold(
                function () {
                  return e(
                    En.error({ type: "error", message: "File not found" })
                  );
                },
                function (n) {
                  return e(En.value(n.uuid));
                }
              );
          });
        });
      },
      mkdir: function (a, f) {
        return c("mkdir").bindFuture(function (i) {
          return _n.nu(function (n) {
            var e,
              t,
              r,
              o,
              u = ke(),
              e = {
                uuid: u,
                type: "directory",
                parentUuid: k(f)
                  ? ((e = f), (t = i), D.from(e).or(t.get().rootUuid))
                  : D.none(),
                name: a,
                size: 0,
                modificationDate: new Date(),
                url: D.none(),
                thumbUrl: D.none(),
                starred: !1,
                path: D.none()
              };
            (t = i.get().files),
              (r = D.from(f)),
              (o = a),
              h(
                v(t, function (n) {
                  return r.fold(
                    function () {
                      return n.parentUuid.isNone();
                    },
                    function (e) {
                      return n.parentUuid.exists(function (n) {
                        return n === e;
                      });
                    }
                  );
                }),
                function (n) {
                  return "directory" === n.type && n.name === o;
                }
              )
                ? n(
                    En.error({ type: "x", message: "Directory already exists" })
                  )
                : (Rt(i, i.get().files.concat([e])), n(En.value(u)));
          });
        });
      },
      upload: function (e) {
        return c("upload").bindFuture(function (n) {
          return Bt(n, (n = e).blob, n.name, n.thumbBlob, n.parent).bindFuture(
            Nt(n.progress)
          );
        });
      },
      list: function (u) {
        return c("list").bindFuture(function (o) {
          return _n.nu(function (n) {
            var e = v(o.get().files, function (n) {
                return (
                  (e = u),
                  (t = n),
                  (r = o.get().rootUuid),
                  e.parentUuid.fold(
                    function () {
                      return r.fold(
                        function () {
                          return t.parentUuid.isNone();
                        },
                        function (e) {
                          return t.parentUuid.exists(function (n) {
                            return n === e;
                          });
                        }
                      );
                    },
                    function (e) {
                      return t.parentUuid.exists(function (n) {
                        return n === e;
                      });
                    }
                  ) &&
                    At(u, n) &&
                    Ct(u, n)
                );
                var e, t, r;
              }),
              t = _e(e, u.sortBy, u.sortOrder),
              r = t.slice(u.offset, u.offset + a.limit),
              e = u.offset + r.length;
            n(En.value({ last: e >= t.length, offset: e, files: r }));
          });
        });
      },
      listStarred: function (i) {
        return c("listStarred").bindFuture(function (u) {
          return _n.nu(function (n) {
            var e = u.get().claims.root,
              t = T(u.get().files, function (n) {
                var e = Mt(n, u.get().files);
                return f(u.get(), e) && At(i, e) && Ct(i, n) && !0 === e.starred
                  ? [e]
                  : [];
              }),
              r = _e(t, i.sortBy, i.sortOrder),
              o = r.slice(i.offset, i.offset + a.limit),
              t = i.offset + o.length;
            n(En.value({ last: t >= r.length, offset: t, files: s(o, e) }));
          });
        });
      },
      search: function (i) {
        return c("search").bindFuture(function (u) {
          return _n.nu(function (n) {
            var e = u.get().claims.root,
              t = T(u.get().files, function (n) {
                var e = Mt(n, u.get().files);
                return f(u.get(), e) &&
                  At(i, e) &&
                  Ct(i, n) &&
                  "directory" !== n.type
                  ? [e]
                  : [];
              }),
              r = _e(t, i.sortBy, i.sortOrder),
              o = r.slice(i.offset, i.offset + a.limit),
              t = i.offset + o.length;
            n(En.value({ last: t >= r.length, offset: t, files: s(o, e) }));
          });
        });
      },
      remove: function (t) {
        return c("remove").bindFuture(function (e) {
          return _n.nu(function (n) {
            Rt(
              e,
              T(e.get().files, function (n) {
                return p(t, n.uuid) ? [] : [n];
              })
            ),
              n(En.value(t));
          });
        });
      },
      copy: function (r, o) {
        return c("copy").bindFuture(function (t) {
          return _n.nu(function (n) {
            var e = ke();
            Rt(
              t,
              T(t.get().files, function (n) {
                return n.uuid === r
                  ? [n, Ke(n, { uuid: e, parentUuid: D.from(o) })]
                  : [n];
              })
            ),
              t.get().meta[r] && u(t, e, t.get().meta[r]),
              n(En.value(e));
          });
        });
      },
      move: function (t, r) {
        return c("move").bindFuture(function (e) {
          return _n.nu(function (n) {
            Rt(
              e,
              g(e.get().files, function (n) {
                return p(t, n.uuid) ? Ke(n, { parentUuid: D.from(r) }) : n;
              })
            ),
              n(En.value(t));
          });
        });
      },
      star: function (t) {
        return c("star").bindFuture(function (e) {
          return _n.nu(function (n) {
            Rt(
              e,
              g(e.get().files, function (n) {
                return p(t, n.uuid) ? Ke(n, { starred: !0 }) : n;
              })
            ),
              n(En.value(t));
          });
        });
      },
      unstar: function (t) {
        return c("unstar").bindFuture(function (e) {
          return _n.nu(function (n) {
            Rt(
              e,
              g(e.get().files, function (n) {
                return p(t, n.uuid) ? Ke(n, { starred: !1 }) : n;
              })
            ),
              n(En.value(t));
          });
        });
      },
      setMeta: function (r, o) {
        return c("setMeta").bindFuture(function (t) {
          return _n.nu(function (e) {
            rr(r, t.get().files).fold(
              function () {
                return e(En.error({ type: "error", message: "No file!!" }));
              },
              function (n) {
                u(t, r, { description: o.description }), e(En.value(n.uuid));
              }
            );
          });
        });
      },
      getMeta: function (r) {
        return c("getMeta").bindFuture(function (t) {
          return _n.nu(function (e) {
            rr(r, t.get().files).fold(
              function () {
                return e(En.error({ type: "error", message: "No file!!" }));
              },
              function () {
                var n = t.get().meta[r];
                e(En.value(n || { description: "", createdBy: D.none() }));
              }
            );
          });
        });
      },
      uploadToPath: function (e) {
        return c("uploadToPath").bindFuture(function (n) {
          return zt(n, e);
        });
      }
    };
  }
  function Jt(n, e) {
    return e && !/^https?:/.test(e) ? Xe(n, e) : e;
  }
  function Vt(n, t) {
    var e = _n.wrap(
      ((e = { url: t, responseType: vn.JSON }),
      ve(_(_({}, e), { method: "get", body: ye() })).map(function (n) {
        return n.fold(
          function (n) {
            return En.error({ type: "", message: "fs error" });
          },
          function (n) {
            return En.value(
              ((e = Ue(t).replace(/\/[^\/]*\/?$/, "")),
              (n = n.files),
              g(n, function (n) {
                return _(_({}, n), {
                  url: Jt(e, n.url),
                  thumbUrl: Jt(e, n.thumbUrl)
                });
              }))
            );
            var e;
          }
        );
      }))
    );
    return Gt(n, e.toCached());
  }
  function qt(r, o) {
    return o(!1).bindFuture(function (n) {
      return r(n).bind(function (n) {
        return n.fold(
          ((e = o),
          (t = r),
          function (n) {
            return 401 === n.status ? e(!0).bindFuture(t) : _n.error(n);
          }),
          _n.pure
        );
        var e, t;
      });
    });
  }
  function Ht(e, n) {
    return qt(function (n) {
      return be(
        _(_({}, e), {
          headers: (function (n, e) {
            e = { Authorization: "Bearer " + e };
            return n ? _(_({}, n), e) : e;
          })(e.headers, n)
        })
      );
    }, n);
  }
  var Wt,
    Kt = function (n, e) {
      n = ct(n);
      return 0 < n.errors.length
        ? bt(n.errors)
        : ((n = n.values),
          (e = e),
          0 < n.length ? ft(We(e, Ke.apply(void 0, n))) : ft(e));
    },
    Xt = function (n) {
      n = ct(n);
      return 0 < n.errors.length ? bt(n.errors) : ft(n.values);
    },
    N = P([
      { field: ["key", "okey", "presence", "prop"] },
      { state: ["okey", "instantiator"] }
    ]),
    Yt = l(xt(ft)),
    $t = N.field,
    z = function (t, r) {
      return xt(function (n) {
        var e = typeof n;
        return t(n) ? ft(n) : st("Expected type: " + r + " but got: " + e);
      });
    },
    Zt = z(A, "number"),
    Qt = z(k, "string"),
    nr = z(L, "boolean"),
    er = z(M, "function"),
    Dn = function (n) {
      return Dt(n, Zt);
    },
    n = function (n) {
      return Dt(n, Qt);
    },
    jn = function (n) {
      return Dt(n, nr);
    },
    R = function (n, e) {
      return $t(n, n, gt(), St(e));
    },
    P = function (n) {
      return (e = Qt), $t((n = n), n, vt(), e);
      var e;
    },
    tr = Ft([
      n("name"),
      n("sub"),
      P("root"),
      $t("https://claims.tiny.cloud/drive/root", "root", vt(), Qt)
    ]),
    rr = function (e, n) {
      return b(n, function (n) {
        return n.uuid === e;
      });
    };
  ((N = Wt = Wt || {}).Thumbnail = "thumbnail"), (N.File = "file");
  function or(n, e, t) {
    return Et(n, e, t.data);
  }
  function ur(n) {
    return (
      (e = O(n.thumbs)),
      (t = n.url),
      (n = function (n, e) {
        return e + "-" + n;
      }),
      e.isSome() && t.isSome()
        ? D.some(n(e.getOrDie(), t.getOrDie()))
        : D.none()
    );
    var e, t;
  }
  function ir(n) {
    return {
      uuid: n.id,
      parentUuid: D.none(),
      name: n.name,
      size: n.size,
      type: ((e = n.type), Je(e).getOr("document")),
      modificationDate:
        ((e = n.mdate),
        D.from(
          /^([0-9]{4})\-([0-9]{2})\-([0-9]{2})T([0-9]{2})\:([0-9]{2})\:([0-9]{2})Z$/.exec(
            e
          )
        )
          .map(function (n) {
            n = g(n.slice(1), function (n) {
              return parseInt(n, 10);
            });
            return new Date(Date.UTC(n[0], n[1] - 1, n[2], n[3], n[4], n[5]));
          })
          .getOr(new Date())),
      url: n.url,
      thumbUrl: ur(n),
      starred: n.starred,
      path: n.path
    };
    var e;
  }
  function ar(n, e, t, r) {
    return { last: e, offset: t, files: g(n, ir) };
  }
  function fr(n, t) {
    return (
      (n = W(n, function (n, e) {
        return t[e](n);
      })),
      (n = X(n, function (n) {
        return n.isSome();
      }).t),
      (n = W(n, function (n) {
        return n.fold(function () {
          return null;
        }, r);
      })),
      ce(n)
    );
  }
  var cr,
    sr = ce,
    z = Ft([
      n("id"),
      n("name"),
      Dn("size"),
      n("type"),
      n("mdate"),
      P("url"),
      R("thumbs", Qt),
      jn("starred"),
      P("path")
    ]),
    lr = Ft([Dt("file", z)]),
    dr = Ft([R("id", Qt)]);
  ((N = cr = cr || {}).Thumbnail = "thumbnail"), (N.File = "file");
  function mr(n) {
    return fr(n, {
      fileType: D.some,
      parent: r,
      path: r,
      name: D.some,
      size: D.some
    });
  }
  function pr(n) {
    return (
      (n = n =
        y(
          n,
          function (n, e) {
            return (n[e.name] = e.value), n;
          },
          {}
        )),
      { type: vn.MultipartFormData, data: n }
    );
  }
  function hr(n) {
    return or("create", ao, n);
  }
  function gr(n) {
    return or("error", fo, n).fold(
      function () {
        return or("error", co, n).map(function (n) {
          return {
            error: { type: D.none(), data: D.none(), message: n.message }
          };
        });
      },
      function (n) {
        return En.value(n);
      }
    );
  }
  function vr(n) {
    return fr(n, {
      offset: D.some,
      parent: r,
      sortBy: r,
      sortOrder: r,
      query: r,
      fileTypes: D.some
    });
  }
  function yr(n) {
    return or("fileListResult", so, n);
  }
  function br(n, e) {
    return ar(e.files, e.last, e.offset);
  }
  function wr(e) {
    return gr(ce(e.responseText)).fold(
      function (n) {
        return {
          type: "",
          message: "Error: " + e.message + " (" + e.status + ")"
        };
      },
      function (n) {
        return { type: "", message: n.error.message };
      }
    );
  }
  function Tr(n) {
    return { type: "", message: "Could not decode http json response" };
  }
  function Or(n, e, t) {
    var r,
      n = Ht(
        {
          url:
            ((r = e),
            Xe((e = n).restApiEndpoint, "/1", r) +
              "?apiKey=" +
              encodeURIComponent(e.apiKey)),
          body: t,
          responseType: vn.JSON
        },
        n.jwtTokenFactory
      );
    return _n.wrap(
      n.foldResult(
        function (n) {
          return En.error(wr(n));
        },
        function (n) {
          return En.value(ce(n));
        }
      )
    );
  }
  function xr(n) {
    return g(n, Ge);
  }
  function Fr(n, e, t) {
    return Or(
      n,
      "client/files/stars",
      ((e = {
        offset: e.offset,
        sortBy: D.some(e.sortBy),
        sortOrder: D.some(e.sortOrder),
        query: e.query,
        fileTypes: xr(e.fileTypes)
      }),
      fr(e, {
        offset: D.some,
        sortBy: r,
        sortOrder: r,
        query: r,
        fileTypes: D.some
      }))
    ).bindResult(function (n) {
      return or("starsResult", To, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function (n) {
          return En.value((D.none(), ar((n = n).files, n.last, n.offset)));
        }
      );
    });
  }
  function Sr(n, e, t) {
    return Or(
      n,
      "client/files/mkdir",
      fr({ parent: e, name: t }, { parent: r, name: D.some })
    ).bindResult(function (n) {
      return or("mkdir", mo, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function (n) {
          return En.value(n.file.id);
        }
      );
    });
  }
  function Er(n, e, t) {
    return Or(n, "client/files/rename", go({ id: e, name: t })).bindResult(
      function (n) {
        return or("rename", vo, n).fold(
          function (n) {
            return En.error(Tr());
          },
          function () {
            return En.value(e);
          }
        );
      }
    );
  }
  function Ur(n, e) {
    return Or(
      n,
      "client/files/delete",
      fr({ ids: e }, { ids: D.some })
    ).bindResult(function (n) {
      return or("remove", ho, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function () {
          return En.value(e);
        }
      );
    });
  }
  function Dr(n, e, t) {
    return Or(n, "client/files/commit", sr({ id: e, type: t })).bindResult(
      function (n) {
        return or("commit", lr, n).fold(
          function (n) {
            return En.error(Tr());
          },
          function (n) {
            return En.value(n);
          }
        );
      }
    );
  }
  function _r(n, e, t, r, o) {
    return Or(
      n,
      "client/files/create",
      mr({ fileType: e, parent: t, path: D.none(), name: r, size: o })
    ).bindResult(function (n) {
      return hr(n).fold(
        function (n) {
          return En.error(Tr());
        },
        function (n) {
          return En.value(n);
        }
      );
    });
  }
  function Rr(n, t, r, e, o) {
    var u = pr(t.formItems);
    return (
      (u.data.file = e),
      (u = be({
        url: t.uploadUrl,
        body: u,
        responseType: vn.Text,
        progress: function (n, e) {
          return o({ loaded: n, total: e, name: r, uuid: t.id });
        }
      })),
      _n.wrap(
        u.foldResult(
          function (n) {
            return En.error(wr(n));
          },
          function (n) {
            return En.value(t.id);
          }
        )
      )
    );
  }
  function Pr(e, t, r, o, n) {
    return (
      (u = e),
      (i = cr.File),
      (a = n),
      (f = r),
      (n = t.size),
      Or(
        u,
        "client/files/create",
        mr({ fileType: i, parent: D.none(), path: D.some(a), name: f, size: n })
      )
        .bindResult(function (n) {
          return hr(n).fold(
            function (n) {
              return En.error(Tr());
            },
            function (n) {
              return En.value(n);
            }
          );
        })
        .bindFuture(function (n) {
          return Rr(0, n, r, t, o)
            .bindFuture(function (n) {
              return Dr(e, n, Wt.File);
            })
            .mapResult(function (n) {
              return ir(n.file);
            });
        })
    );
    var u, i, a, f;
  }
  function kr(u, n, i) {
    return function (o) {
      return n.fold(
        function () {
          return _n.value(o);
        },
        function (n) {
          return (
            (e = u),
            (t = n),
            (r = i),
            (n = o.uuid),
            _r(e, cr.Thumbnail, D.from(n), r, t.size)
              .bindFuture(function (n) {
                return Rr(0, n, r, t, m);
              })
              .bindFuture(function (n) {
                return Dr(e, n, Wt.Thumbnail);
              })
              .mapResult(function (n) {
                return n.file.id;
              })
              .bindResult(function (n) {
                return En.value(o);
              })
          );
          var e, t, r;
        }
      );
    };
  }
  function Ir(n, e, t) {
    return Or(
      n,
      "client/files/move",
      fr({ ids: e, parent: t }, { parent: r, ids: D.some })
    ).bindResult(function (n) {
      return or("move", po, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function () {
          return En.value(e);
        }
      );
    });
  }
  function jr(n, e, t) {
    return Or(
      n,
      "client/files/copy",
      fr({ id: e, parent: t }, { parent: r, id: D.some })
    ).bindResult(function (n) {
      return or("copy", dr, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function () {
          return En.value(e);
        }
      );
    });
  }
  function Lr(n, e) {
    return Or(n, "client/files/star", bo({ ids: e })).bindResult(function (n) {
      return or("star", wo, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function () {
          return En.value(e);
        }
      );
    });
  }
  function Mr(n, e) {
    return Or(n, "client/files/unstar", Oo({ ids: e })).bindResult(function (
      n
    ) {
      return or("unstar", xo, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function () {
          return En.value(e);
        }
      );
    });
  }
  function Ar(n, e, t) {
    return Or(
      n,
      "client/files/setMeta",
      ((t = { id: e, description: t.description }),
      fr(t, { id: D.some, description: D.some }))
    ).bindResult(function (n) {
      return or("setFileMeta", yo, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function (n) {
          return En.value(e);
        }
      );
    });
  }
  function Cr(n, e) {
    return Or(
      n,
      "client/files/getMeta",
      fr({ id: e }, { id: D.some })
    ).bindResult(function (n) {
      return or("getFileMeta", lo, n).fold(
        function (n) {
          return En.error(Tr());
        },
        function (n) {
          return En.value({
            description: n.description,
            createdBy: n.createdBy
          });
        }
      );
    });
  }
  function Br(i) {
    return {
      rename: function (n, e) {
        return Er(i, n, e);
      },
      mkdir: function (n, e) {
        return Sr(i, D.from(e), n);
      },
      upload: function (n) {
        return (
          (e = i),
          (t = n.blob),
          (r = n.name),
          (o = n.progress),
          (u = n.parent),
          _r(e, cr.File, u, r, t.size)
            .bindFuture(function (n) {
              return Rr(0, n, r, t, o)
                .bindFuture(function (n) {
                  return Dr(e, n, Wt.File);
                })
                .mapResult(function (n) {
                  return ir(n.file);
                });
            })
            .bindFuture(kr(i, n.thumbBlob, n.name))
        );
        var e, t, r, o, u;
      },
      list: function (n) {
        return Or(
          i,
          "client/files/list",
          vr({
            offset: (n = n).offset,
            parent: n.parentUuid,
            sortBy: D.some(n.sortBy),
            sortOrder: D.some(n.sortOrder),
            query: n.query,
            fileTypes: xr(n.fileTypes)
          })
        ).bindResult(function (n) {
          return yr(n).fold(
            function (n) {
              return En.error(Tr());
            },
            function (n) {
              return En.value(br(D.none(), n));
            }
          );
        });
      },
      listStarred: function (n) {
        return Fr(i, n);
      },
      search: function (n) {
        return Or(
          i,
          "client/files/search",
          vr({
            offset: (n = n).offset,
            parent: D.none(),
            sortBy: D.some(n.sortBy),
            sortOrder: D.some(n.sortOrder),
            query: n.query,
            fileTypes: xr(n.fileTypes)
          })
        ).bindResult(function (n) {
          return yr(n).fold(
            function (n) {
              return En.error(Tr());
            },
            function (n) {
              return En.value(br(D.none(), n));
            }
          );
        });
      },
      remove: function (n) {
        return Ur(i, n);
      },
      copy: function (n, e) {
        return jr(i, n, D.from(e));
      },
      move: function (n, e) {
        return Ir(i, n, D.from(e));
      },
      star: function (n) {
        return Lr(i, n);
      },
      unstar: function (n) {
        return Mr(i, n);
      },
      setMeta: function (n, e) {
        return Ar(i, n, e);
      },
      getMeta: function (n) {
        return Cr(i, n);
      },
      uploadToPath: function (n) {
        return Pr(i, n.blob, n.name, n.progress, n.path).bindFuture(
          kr(i, n.thumbBlob, n.name)
        );
      }
    };
  }
  function Nr(n) {
    var e = n.jwtTokenFactory;
    return n.demoFilesUrl.fold(
      function () {
        return n.demoFiles.fold(
          function () {
            return (function (n, e, t) {
              (e = e.getOrDie("Failed to get service url")),
                (t = t.getOrDie("Failed to get api key"));
              return Br({ jwtTokenFactory: n, restApiEndpoint: e, apiKey: t });
            })(e, n.serviceUrl, n.apiKey);
          },
          function (n) {
            return (
              (n = n),
              Gt(
                { jwtTokenFactory: e, requestDelay: 0, log: !1, limit: 30 },
                _n.pure(n)
              )
            );
          }
        );
      },
      function (n) {
        return Vt(
          { jwtTokenFactory: e, requestDelay: 0, log: !1, limit: 30 },
          n
        );
      }
    );
  }
  function zr(n) {
    return "media" === n
      ? ["directory", "video", "audio"]
      : "image" === n
      ? ["directory", "image"]
      : [];
  }
  function Gr(n, e) {
    var t = D.from(V("ui.FloatPanel.currentZIndex", tinymce)).getOr(65536),
      r = Se(e),
      o =
        ((u = e),
        D.from(u.getParam("tinydrive_dropbox_app_key", null, "string"))),
      u =
        ((u = e),
        D.from(u.getParam("tinydrive_google_drive_key", null, "string"))),
      e =
        ((e = e),
        D.from(e.getParam("tinydrive_google_drive_client_id", null, "string")));
    return {
      close: !0,
      insert: !0,
      fullscreen: !1,
      target: D.none(),
      fileTypes: [],
      zIndex: t,
      maxImageDimension: r,
      dropboxAppKey: o,
      googleDriveDeveloperKey: u,
      googleDriveClientId: e,
      baseUrl: n
    };
  }
  function Jr(n, e) {
    return sn({
      js:
        ((t = e + "/assetmanager.min.js"),
        n.getParam("tinydrive_script_url", t, "string")),
      css: Ee(n, e)
    });
    var t;
  }
  function Vr(o, u, i, a) {
    return On(function (r) {
      Jr(o, u).get(function (n) {
        n.fold(
          function (n) {
            console.error(n);
          },
          function (n) {
            var e,
              t = m,
              t = n(
                i,
                ((e = Gr(u, o)),
                (n = a),
                D.from(n.filetype)
                  .map(zr)
                  .fold(l(e), function (n) {
                    return _(_({}, e), { fileTypes: n });
                  })),
                function (n) {
                  t(), r(n);
                }
              );
          }
        );
      });
    });
  }
  function qr(r, o) {
    o.url.each(function (n) {
      var e, t;
      r.insertContent(
        ((t = o.name),
        ze(t).is("image")
          ? ((e = n), r.dom.createHTML("img", { src: e }))
          : ((t = n),
            (e = o),
            (n = r).dom.createHTML("a", { href: t }, n.dom.encode(e.name))))
      );
    });
  }
  function Hr(e, n, t) {
    Vr(e, n, t, { filetype: "" }).get(function (n) {
      s(n, function (n) {
        return qr(e, n), 0;
      });
    });
  }
  function Wr(n, e, t) {
    var r, o, u, i, a, f;
    n.ui
      ? ((a = e),
        (f = t),
        (i = n).ui.registry.addButton("insertfile", {
          icon: "browse",
          tooltip: "Insert file",
          onAction: function () {
            return Hr(i, a, f);
          }
        }))
      : ((o = e),
        (u = t),
        (r = n).addButton("insertfile", {
          icon: "browse",
          tooltip: "Insert file",
          onclick: function () {
            return Hr(r, o, u);
          }
        }));
  }
  function Kr(n, e, t) {
    var r, o, u, i, a, f;
    n.ui
      ? ((a = e),
        (f = t),
        (i = n).ui.registry.addMenuItem("insertfile", {
          icon: "browse",
          text: "File",
          onAction: function () {
            return Hr(i, a, f);
          }
        }))
      : ((o = e),
        (u = t),
        (r = n).addMenuItem("insertfile", {
          icon: "browse",
          text: "File",
          onclick: function () {
            return Hr(r, o, u);
          }
        }));
  }
  function Xr(n, e) {
    return Nr({
      demoFilesUrl:
        ((r = n),
        D.from(r.getParam("tinydrive_demo_files_url", null, "string"))),
      demoFiles: ((r = n), D.from(r.getParam("tinydrive_demo_files"))),
      jwtTokenFactory: (function (n, e) {
        n = n.getParam("tinydrive_token_provider");
        return xe(n, e);
      })(n, e),
      serviceUrl:
        ((e = n), D.from(e.getParam("tinydrive_service_url", null, "string"))),
      apiKey:
        ((t = n),
        D.from(t.getParam("tinydrive_api_key", null, "string")).orThunk(
          function () {
            return D.from(t.getParam("api_key", null, "string"));
          }
        ))
    });
    var t, r;
  }
  function Yr(n, e) {
    return So(document.createElement("canvas"), n, e);
  }
  function $r(n) {
    var e = Yr(n.width, n.height);
    return Fo(e).drawImage(n, 0, 0), e;
  }
  function Zr(n) {
    return n.naturalWidth || n.width;
  }
  function Qr(n) {
    return n.naturalHeight || n.height;
  }
  var no,
    eo,
    to,
    ro,
    oo,
    uo,
    io,
    ao = Ft([
      n("uploadUrl"),
      n("blobUrl"),
      R("formItems", Ft([n("name"), n("value")])),
      n("id")
    ]),
    fo = Ft([
      ((no = "error"),
      (eo = [P("type"), P("data"), n("message")]),
      $t(no, no, gt(), Ft(eo)))
    ]),
    co = Ft([n("message")]),
    so = Ft([jn("last"), Dn("offset"), R("files", z)]),
    lo = Ft([n("id"), n("description"), P("createdBy")]),
    mo = Ft([Dt("file", z)]),
    po = Ft([R("ids", Qt)]),
    ho = Ft([R("ids", Qt)]),
    go = ce,
    vo = Ft([Dt("file", z)]),
    yo = Ft([n("id")]),
    bo = ce,
    wo = Ft([R("ids", Qt)]),
    To = Ft([jn("last"), Dn("offset"), R("files", z)]),
    Oo = ce,
    xo = Ft([R("ids", Qt)]),
    Fo = function (n) {
      return n.getContext("2d");
    },
    So = function (n, e, t) {
      return (n.width = e), (n.height = t), n;
    },
    Eo =
      window.Promise ||
      ((to = window),
      (ro =
        Uo.immediateFn ||
        ("function" == typeof to.setImmediate && to.setImmediate) ||
        function (n) {
          return setTimeout(n, 1);
        }),
      (oo = function (t, r) {
        return function () {
          for (var n = [], e = 0; e < arguments.length; e++)
            n[e] = arguments[e];
          return t.apply(r, n);
        };
      }),
      (uo =
        Array.isArray ||
        function (n) {
          return "[object Array]" === Object.prototype.toString.call(n);
        }),
      (io = function (n, e, t) {
        var r = !1;
        try {
          n(
            function (n) {
              r || ((r = !0), e(n));
            },
            function (n) {
              r || ((r = !0), t(n));
            }
          );
        } catch (n) {
          if (r) return;
          (r = !0), t(n);
        }
      }),
      (Uo.prototype.catch = function (n) {
        return this.then(null, n);
      }),
      (Uo.prototype.then = function (t, r) {
        var o = this;
        return new Uo(function (n, e) {
          Do.call(o, new ko(t, r, n, e));
        });
      }),
      (Uo.all = function () {
        for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
        var a = Array.prototype.slice.call(
          1 === n.length && uo(n[0]) ? n[0] : n
        );
        return new Uo(function (r, o) {
          if (0 === a.length) return r([]);
          for (
            var u = a.length,
              i = function (e, n) {
                try {
                  if (n && ("object" == typeof n || "function" == typeof n)) {
                    var t = n.then;
                    if ("function" == typeof t)
                      return void t.call(
                        n,
                        function (n) {
                          i(e, n);
                        },
                        o
                      );
                  }
                  (a[e] = n), 0 == --u && r(a);
                } catch (n) {
                  o(n);
                }
              },
              n = 0;
            n < a.length;
            n++
          )
            i(n, a[n]);
        });
      }),
      (Uo.resolve = function (e) {
        return e && "object" == typeof e && e.constructor === Uo
          ? e
          : new Uo(function (n) {
              n(e);
            });
      }),
      (Uo.reject = function (t) {
        return new Uo(function (n, e) {
          e(t);
        });
      }),
      (Uo.race = function (o) {
        return new Uo(function (n, e) {
          for (var t = 0, r = o; t < r.length; t++) r[t].then(n, e);
        });
      }),
      Uo);
  function Uo(n) {
    if ("object" != typeof this)
      throw new TypeError("Promises must be constructed via new");
    if ("function" != typeof n) throw new TypeError("not a function");
    (this._state = null),
      (this._value = null),
      (this._deferreds = []),
      io(n, oo(_o, this), oo(Ro, this));
  }
  function Do(t) {
    var r = this;
    null !== this._state
      ? ro(function () {
          var n,
            e = r._state ? t.onFulfilled : t.onRejected;
          if (null !== e) {
            try {
              n = e(r._value);
            } catch (n) {
              return void t.reject(n);
            }
            t.resolve(n);
          } else (r._state ? t.resolve : t.reject)(r._value);
        })
      : this._deferreds.push(t);
  }
  function _o(n) {
    try {
      if (n === this)
        throw new TypeError("A promise cannot be resolved with itself.");
      if (n && ("object" == typeof n || "function" == typeof n)) {
        var e = n.then;
        if ("function" == typeof e)
          return void io(oo(e, n), oo(_o, this), oo(Ro, this));
      }
      (this._state = !0), (this._value = n), Po.call(this);
    } catch (n) {
      Ro.call(this, n);
    }
  }
  function Ro(n) {
    (this._state = !1), (this._value = n), Po.call(this);
  }
  function Po() {
    for (var n = 0, e = this._deferreds; n < e.length; n++) {
      var t = e[n];
      Do.call(this, t);
    }
    this._deferreds = [];
  }
  function ko(n, e, t, r) {
    (this.onFulfilled = "function" == typeof n ? n : null),
      (this.onRejected = "function" == typeof e ? e : null),
      (this.resolve = t),
      (this.reject = r);
  }
  function Io(a) {
    return new Eo(function (n, e) {
      function t() {
        o.removeEventListener("load", u), o.removeEventListener("error", i);
      }
      var r = URL.createObjectURL(a),
        o = new Image(),
        u = function () {
          t(), n(o);
        },
        i = function () {
          t(), e("Unable to load data of type " + a.type + ": " + r);
        };
      o.addEventListener("load", u),
        o.addEventListener("error", i),
        (o.src = r),
        o.complete && setTimeout(u, 0);
    });
  }
  function jo(t) {
    return new Eo(function (n, e) {
      !(function (n) {
        var e = n.split(","),
          n = /data:([^;]+)/.exec(e[0]);
        if (!n) return D.none();
        for (
          var n = n[1],
            e = e[1],
            t = atob(e),
            r = t.length,
            o = Math.ceil(r / 1024),
            u = new Array(o),
            i = 0;
          i < o;
          ++i
        ) {
          for (
            var a = 1024 * i,
              f = Math.min(1024 + a, r),
              c = new Array(f - a),
              s = a,
              l = 0;
            s < f;
            ++l, ++s
          )
            c[l] = t[s].charCodeAt(0);
          u[i] = new Uint8Array(c);
        }
        return D.some(new Blob(u, { type: n }));
      })(t).fold(function () {
        e("uri is not base64: " + t);
      }, n);
    });
  }
  function Lo(n, r, o) {
    return (
      (r = r || "image/png"),
      M(HTMLCanvasElement.prototype.toBlob)
        ? new Eo(function (e, t) {
            n.toBlob(
              function (n) {
                n ? e(n) : t();
              },
              r,
              o
            );
          })
        : jo(n.toDataURL(r, o))
    );
  }
  function Mo(n, e, t) {
    function r(r, o) {
      return n.then(function (n) {
        return (e = r), (t = o), n.toDataURL((e = e || "image/png"), t);
        var e, t;
      });
    }
    var o = e.type,
      u = l(o),
      o = l(t);
    return {
      getType: u,
      toBlob: function () {
        return Eo.resolve(e);
      },
      toDataURL: o,
      toBase64: function () {
        return t.split(",")[1];
      },
      toAdjustedBlob: function (e, t) {
        return n.then(function (n) {
          return Lo(n, e, t);
        });
      },
      toAdjustedDataURL: r,
      toAdjustedBase64: function (n, e) {
        return r(n, e).then(function (n) {
          return n.split(",")[1];
        });
      },
      toCanvas: function () {
        return n.then($r);
      }
    };
  }
  function Ao(e, n) {
    return Lo(e, n).then(function (n) {
      return Mo(Eo.resolve(e), n, e.toDataURL());
    });
  }
  function Co(e) {
    return (
      (t = e),
      new Eo(function (n) {
        var e = new FileReader();
        (e.onloadend = function () {
          n(e.result);
        }),
          e.readAsDataURL(t);
      }).then(function (n) {
        return Mo(
          Io(e).then(function (n) {
            Bo(n);
            var e = Yr(Zr(n), Qr(n));
            return Fo(e).drawImage(n, 0, 0), e;
          }),
          e,
          n
        );
      })
    );
    var t;
  }
  var Bo = function (n) {
      URL.revokeObjectURL(n.src);
    },
    No =
      ((zo.prototype.readByteAt = function (n) {
        return this.dataView.getUint8(n);
      }),
      (zo.prototype.read = function (n, e) {
        if (n + e > this.length())
          return En.error("Read extends past buffer end");
        for (
          var t = this.littleEndian ? 0 : -8 * (e - 1), r = 0, o = 0;
          o < e;
          o++
        )
          r |= this.readByteAt(n + o) << Math.abs(t + 8 * o);
        return En.value(r);
      }),
      (zo.prototype.segment = function (n, e) {
        var t = this.dataView.buffer;
        return void 0 !== n && void 0 !== e
          ? t.slice(n, n + e)
          : void 0 !== n
          ? t.slice(n)
          : t;
      }),
      (zo.prototype.length = function () {
        return this.dataView.byteLength;
      }),
      zo);
  function zo(n) {
    (this.littleEndian = !1), (this.dataView = new DataView(n));
  }
  function Go(n, e, t, r, o) {
    if (e + t * r > n.length())
      return En.error("Read would extend past end of buffer");
    for (var u = [], i = 0; i < r; i++) {
      var a = o(n, e + t * i);
      if (a.isError())
        return a.map(function (n) {
          return [n];
        });
      u.push(a.getOrDie());
    }
    return En.value(u);
  }
  function Jo(n, e) {
    return n.read(e, 1);
  }
  function Vo(n, e) {
    return n.read(e, 2);
  }
  function qo(n, e) {
    return n.read(e, 4);
  }
  function Ho(n) {
    return En.value(String.fromCharCode(n));
  }
  function Wo(n) {
    return En.value(2147483647 < n ? n - 4294967296 : n);
  }
  function Ko(n, e) {
    return qo(n, e).bind(Wo);
  }
  function Xo(n, e) {
    return Jo(n, e).bind(Ho);
  }
  function Yo(n, e, t) {
    return Go(n, e, 1, (t = void 0 === t ? 1 : t), Xo).map(function (n) {
      return n.join("");
    });
  }
  function $o(n, t) {
    return qo(n, t).bind(function (e) {
      return qo(n, t + 4).map(function (n) {
        return e / n;
      });
    });
  }
  function Zo(n, t) {
    return Ko(n, t).bind(function (e) {
      return Ko(n, t + 4).map(function (n) {
        return e / n;
      });
    });
  }
  function Qo(f, o, c, s) {
    function l(e) {
      return function (n) {
        return D.some([e, n]);
      };
    }
    function d(n) {
      return n.replace(/\0$/, "").trim();
    }
    var m = {
      1: { name: "BYTE", size: 1, read: Jo },
      7: { name: "UNDEFINED", size: 1, read: Jo },
      2: { name: "ASCII", size: 1, read: Jo },
      3: { name: "SHORT", size: 2, read: Vo },
      4: { name: "LONG", size: 4, read: qo },
      5: { name: "RATIONAL", size: 8, read: $o },
      9: { name: "SLONG", size: 4, read: Ko },
      10: { name: "SRATIONAL", size: 8, read: Zo }
    };
    return Vo(f, o).fold(
      function () {
        return En.value({});
      },
      function (n) {
        for (var t = {}, e = 0; e < n; e++) {
          var r = (function (n) {
            var a = o + 2 + 12 * n,
              n = Vo(f, a + 0).bind(function (i) {
                return Vo(f, a + 2).bind(function (u) {
                  return qo(f, a + 4).bind(function (n) {
                    var e = s[i];
                    if (void 0 === e) return En.value(D.none());
                    var t = m[u];
                    if (void 0 === t)
                      return En.error(
                        "Tag with type number " + u + " was unrecognised."
                      );
                    var r = a + 8;
                    if (4 < t.size * n) {
                      var o = qo(f, a + 8);
                      if (o.isError())
                        return o.map(function (n) {
                          return D.none();
                        });
                      r = o.getOrDie() + c;
                    }
                    return r + t.size * n >= f.length()
                      ? En.error("Invalid Exif data.")
                      : (1 === n && void 0 !== Eu[e]
                          ? t.read(f, r).map(function (n) {
                              return Eu[e][n];
                            })
                          : "ASCII" === t.name
                          ? Yo(f, r, n).map(d)
                          : 1 === n
                          ? t.read(f, r)
                          : Go(f, r, t.size, n, t.read)
                        ).map(l(e));
                  });
                });
              });
            if (n.isError())
              return {
                value: n.map(function (n) {
                  return t;
                })
              };
            n.each(function (n) {
              return n.each(function (n) {
                var e = n[0],
                  n = n[1];
                t[e] = n;
              });
            });
          })(e);
          if ("object" == typeof r) return r.value;
        }
        return En.value(t);
      }
    );
  }
  function nu(n) {
    return {
      Orientation: D.from(n.Orientation).filter(A).getOrUndefined(),
      ImageDescription: D.from(n.ImageDescription).filter(k).getOrUndefined(),
      Make: D.from(n.Make).filter(k).getOrUndefined(),
      Model: D.from(n.Model).filter(k).getOrUndefined(),
      Software: D.from(n.Software).filter(k).getOrUndefined(),
      ExifIFDPointer: D.from(n.ExifIFDPointer).filter(A),
      GPSInfoIFDPointer: D.from(n.GPSInfoIFDPointer).filter(A)
    };
  }
  function eu(n) {
    var e;
    return {
      ExifVersion:
        ((e = n.ExifVersion),
        k(e)
          ? e
          : j(e)
          ? g(e, function (n) {
              return A(n) ? String.fromCharCode(n) : "";
            }).join("")
          : void 0),
      ColorSpace: D.from(n.ColorSpace).filter(k).getOrUndefined(),
      PixelXDimension: D.from(n.PixelXDimension).filter(A).getOrUndefined(),
      PixelYDimension: D.from(n.PixelYDimension).filter(A).getOrUndefined(),
      DateTimeOriginal: D.from(n.DateTimeOriginal).filter(k).getOrUndefined(),
      ExposureTime: D.from(n.ExposureTime).filter(A).getOrUndefined(),
      FNumber: D.from(n.FNumber).filter(A).getOrUndefined(),
      ISOSpeedRatings: D.from(n.ISOSpeedRatings).filter(A).getOrUndefined(),
      ShutterSpeedValue: D.from(n.ShutterSpeedValue).filter(A).getOrUndefined(),
      ApertureValue: D.from(n.ApertureValue).filter(A).getOrUndefined(),
      MeteringMode: D.from(n.MeteringMode).filter(k).getOrUndefined(),
      LightSource: D.from(n.LightSource).filter(k).getOrUndefined(),
      Flash: D.from(n.Flash).filter(k).getOrUndefined(),
      FocalLength: D.from(n.FocalLength).filter(A).getOrUndefined(),
      ExposureMode: D.from(n.ExposureMode).filter(k).getOrUndefined(),
      WhiteBalance: D.from(n.WhiteBalance).filter(k).getOrUndefined(),
      SceneCaptureType: D.from(n.SceneCaptureType).filter(k).getOrUndefined(),
      DigitalZoomRatio: D.from(n.DigitalZoomRatio).filter(A).getOrUndefined(),
      Contrast: D.from(n.Contrast).filter(k).getOrUndefined(),
      Saturation: D.from(n.Saturation).filter(k).getOrUndefined(),
      Sharpness: D.from(n.Sharpness).filter(k).getOrUndefined()
    };
  }
  function tu(n) {
    var e;
    return {
      GPSVersionID:
        ((e = n.GPSVersionID),
        k(e)
          ? e
          : j(e)
          ? g(e, function (n) {
              return A(n) ? "" + n : k(n) ? n : "";
            }).join(".")
          : void 0),
      GPSLatitudeRef: D.from(n.GPSLatitudeRef).filter(k).getOrUndefined(),
      GPSLatitude: D.from(n.GPSLatitude).filter(A).getOrUndefined(),
      GPSLongitudeRef: D.from(n.GPSLongitudeRef).filter(k).getOrUndefined(),
      GPSLongitude: D.from(n.GPSLongitude).filter(A).getOrUndefined()
    };
  }
  function ru(n) {
    var e = n.JPEGInterchangeFormat;
    return void 0 !== e &&
      A(e) &&
      void 0 !== (n = n.JPEGInterchangeFormatLength) &&
      A(n)
      ? En.value({ JPEGInterchangeFormat: e, JPEGInterchangeFormatLength: n })
      : En.error("");
  }
  function ou(l) {
    return (
      (t = l),
      new Eo(function (n) {
        var e = new FileReader();
        (e.onloadend = function () {
          n(e.result);
        }),
          e.readAsArrayBuffer(t);
      }).then(function (n) {
        try {
          var e = new No(n);
          if (Vo(e, 0).is(65496)) {
            var t = Uu(e),
              r = t.filter(function (n) {
                return "APP1" === n.name;
              }),
              o = { rawHeaders: t };
            if (!r.length)
              return Eo.reject("Headers did not include required information");
            var u =
              ((i = r[0].segment),
              (a = new No(i)),
              (f =
                Vo(a, 0).is(65505) &&
                Yo(a, 4, 5)
                  .map(function (n) {
                    return n.toUpperCase();
                  })
                  .is("EXIF\0")
                  ? ((a.littleEndian = Vo(a, 10).is(18761)),
                    Vo(a, 12).is(42)
                      ? qo(a, 14).map(function (n) {
                          return 10 + n;
                        })
                      : En.error("Invalid Exif data."))
                  : En.error(
                      "APP1 marker and EXIF marker cannot be read or not available."
                    )),
              (c = f.bind(function (n) {
                return Qo(a, n, 10, Ou).map(nu);
              })),
              (s = c.bind(function (n) {
                return n.ExifIFDPointer.fold(
                  function () {
                    return En.value(D.none());
                  },
                  function (n) {
                    return Qo(a, 10 + n, 10, xu)
                      .map(eu)
                      .map(D.some);
                  }
                );
              })),
              (i = c.bind(function (n) {
                return n.GPSInfoIFDPointer.fold(
                  function () {
                    return En.value(D.none());
                  },
                  function (n) {
                    return Qo(a, 10 + n, 10, Fu)
                      .map(tu)
                      .map(D.some);
                  }
                );
              })),
              {
                tiff: c,
                exif: s,
                gps: i,
                thumb: f
                  .bind(function (e) {
                    return Vo(a, e).map(function (n) {
                      return e + 2 + 12 * n;
                    });
                  })
                  .bind(function (n) {
                    return qo(a, n).map(function (n) {
                      return n + 10;
                    });
                  })
                  .bind(function (n) {
                    return Qo(a, n, 10, Su)
                      .bind(ru)
                      .map(function (n) {
                        return a.segment(
                          10 + n.JPEGInterchangeFormat,
                          n.JPEGInterchangeFormatLength
                        );
                      })
                      .map(D.some);
                  })
              });
            return (
              (o.tiff = u.tiff.getOrDie()),
              (o.exif = Ne(u.exif.toOptional()).getOrNull()),
              (o.gps = Ne(u.gps.toOptional()).getOrNull()),
              (o.thumb = Ne(u.thumb.toOptional()).getOrNull()),
              o
            );
          }
          return Eo.reject("Image was not a jpeg");
        } catch (n) {
          return Eo.reject(
            "Unsupported format or not an image: " +
              l.type +
              " (Exception: " +
              n.message +
              ")"
          );
        }
        var i, a, f, c, s;
      })
    );
    var t;
  }
  function uu(n, e, t) {
    return (
      (o = e),
      (u = t),
      (r = n).toCanvas().then(function (n) {
        return Du(n, o, u).then(function (n) {
          return Ao(n, r.getType());
        });
      })
    );
    var r, o, u;
  }
  function iu(n, e) {
    return (
      (r = e),
      (t = n).toCanvas().then(function (n) {
        return Ru(n, t.getType(), r);
      })
    );
    var t, r;
  }
  function au(e) {
    return e
      .toBlob()
      .then(ou)
      .then(
        function (n) {
          switch (n.tiff.Orientation) {
            case 6:
              return iu(e, 90);
            case 3:
              return iu(e, 180);
            case 8:
              return iu(e, 270);
            default:
              return e;
          }
        },
        function () {
          return e;
        }
      );
  }
  function fu(n, e) {
    return Math.max(n.width / e.width, n.height / e.height);
  }
  function cu(r, o) {
    return (
      (n = r),
      Le(function () {
        return Pu(n).then(function (n) {
          var e = n.naturalWidth,
            t = n.naturalHeight;
          return URL.revokeObjectURL(n.src), { width: e, height: t };
        });
      }).bindFuture(function (n) {
        return 1 < fu(n, o)
          ? ((e = r),
            (t = (function (n, e) {
              e = fu(n, e);
              return {
                width: Math.round(n.width / e),
                height: Math.round(n.height / e)
              };
            })(n, o)),
            Le(function () {
              return Co(e)
                .then(function (n) {
                  return uu(n, t.width, t.height);
                })
                .then(function (n) {
                  return n.toAdjustedBlob(e.type, 9);
                });
            }))
          : _n.value(r);
        var e, t;
      })
    );
    var n;
  }
  function su(n) {
    return _n.fromPromise(
      Co(n)
        .then(te().browser.isIE() ? au : r)
        .then(function (n) {
          return n.toBlob();
        })
    );
  }
  function lu(n, e) {
    return (
      (t = n),
      e
        .map(function (n) {
          return cu(t, { width: n, height: n });
        })
        .getOr(_n.pure(t))
        .bindFuture(su)
        .bindFuture(function (e) {
          return cu(e, { width: 512, height: 512 }).mapResult(function (n) {
            return { blob: e, thumbBlob: D.some(n) };
          });
        })
        .mapError(Re)
    );
    var t;
  }
  function du(n, e) {
    return p(ku, n.type) ? lu(n, e) : _n.pure({ blob: n, thumbBlob: D.none() });
  }
  function mu(e) {
    return du(e.blob, e.maxImageDimension).bindFuture(function (n) {
      return e.fs.uploadToPath({
        blob: n.blob,
        thumbBlob: n.thumbBlob,
        name: e.name,
        progress: e.progress,
        path: e.path
      });
    });
  }
  function pu(n, e, t) {
    var r, u, i, a, f;
    !0 !== M(n.settings.images_upload_handler) &&
      ((r = n.getParam("tinydrive_upload_path", dn("/uploads"), "string")),
      (n.settings.images_upload_handler =
        ((u = e),
        (i = r),
        (a = t),
        (f = Se(n)),
        function (n, e, t, r) {
          var o = M(r)
            ? function (n) {
                return r(Math.round((n.total / n.loaded) * 100));
              }
            : m;
          mu({
            fs: u,
            path: i,
            name: n.filename(),
            blob: n.blob(),
            progress: o,
            maxImageDimension: f
          }).get(function (n) {
            n.fold(
              function (n) {
                return t(n.message);
              },
              function (n) {
                n.url.fold(
                  function () {
                    return t("Failed to get upload url");
                  },
                  function (n) {
                    a(n), e(n);
                  }
                );
              }
            );
          });
        })));
  }
  function hu(n, e) {
    var t = String(n);
    if (t.length < e) for (var r = 0; r < e - t.length; r++) t = "0" + t;
    return t;
  }
  function gu(n) {
    return (
      (e = "%Y-%m-%dT%H:%M:%SZ"),
      (u = n),
      (t = new Date(
        u.getUTCFullYear(),
        u.getUTCMonth(),
        u.getUTCDate(),
        u.getUTCHours(),
        u.getUTCMinutes(),
        u.getUTCSeconds(),
        u.getUTCMilliseconds()
      )),
      (r = "Sun Mon Tue Wed Thu Fri Sat Sun".split(" ")),
      (o =
        "Sunday Monday Tuesday Wednesday Thursday Friday Saturday Sunday".split(
          " "
        )),
      (n = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ")),
      (u =
        "January February March April May June July August September October November December".split(
          " "
        )),
      (e = (e = (e = (e = (e = (e = (e = (e = (e = (e = (e = (e = (e = (e = (e =
        e.replace("%D", "%m/%d/%Y")).replace("%r", "%I:%M:%S %p")).replace(
        "%Y",
        "" + t.getFullYear()
      )).replace("%m", hu(t.getMonth() + 1, 2))).replace(
        "%d",
        hu(t.getDate(), 2)
      )).replace("%H", "" + hu(t.getHours(), 2))).replace(
        "%M",
        "" + hu(t.getMinutes(), 2)
      )).replace("%S", "" + hu(t.getSeconds(), 2))).replace(
        "%I",
        "" + (((t.getHours() + 11) % 12) + 1)
      )).replace("%p", t.getHours() < 12 ? "AM" : "PM")).replace(
        "%B",
        "" + u[t.getMonth()]
      )).replace("%b", "" + n[t.getMonth()])).replace(
        "%A",
        "" + o[t.getDay()]
      )).replace("%a", "" + r[t.getDay()])).replace("%%", "%"))
    );
    var e, t, r, o, u;
  }
  function vu(e) {
    return e.url.map(function (n) {
      return {
        name: e.name,
        url: n,
        size: e.size,
        type: Ge(e.type),
        mdate: gu(e.modificationDate)
      };
    });
  }
  function yu(n) {
    return { files: Be(g(n, vu)) };
  }
  function bu(t, i, a, n, f) {
    return (function (n) {
      n = Et("picker settings", Iu, n).mapError(Ut);
      return _n.fromResult(n);
    })(n)
      .bindFuture(function (n) {
        return (
          (o = a),
          (u = _(_({}, Gr((r = i), (e = t))), {
            fileTypes: (function (n) {
              n = Be(g(n, Je));
              return 0 < n.length ? ["directory"].concat(n) : [];
            })(n.filetypes),
            insert: f
          })),
          _n.nu(function (t) {
            Jr(e, r).get(function (n) {
              n.fold(
                function (n) {
                  return t(En.error(n));
                },
                function (n) {
                  var e = m,
                    e = n(o, u, function (n) {
                      e(), t(En.value(n));
                    });
                }
              );
            });
          })
        );
        var e, r, o, u;
      })
      .mapResult(yu);
  }
  function wu(e, r, n) {
    return (function (n) {
      n = Et("upload settings", ju, n).mapError(Ut);
      return _n.fromResult(n);
    })(n).bindFuture(function (n) {
      return mu({
        fs: r,
        path: n.path,
        name: n.name,
        blob: n.blob,
        progress:
          ((t = n.onprogress),
          function (n) {
            var e = n.loaded,
              n = n.total;
            t({ loaded: e, total: n });
          }),
        maxImageDimension: n.maxImageDimension.or(Se(e))
      })
        .bindResult(function (n) {
          return En.fromOption(
            vu(n).map(function (n) {
              return { file: n };
            }),
            Re("Failed to get upload file")
          );
        })
        .mapError(function (n) {
          return n.message;
        });
      var t;
    });
  }
  var Tu,
    Ou = {
      274: "Orientation",
      270: "ImageDescription",
      271: "Make",
      272: "Model",
      305: "Software",
      34665: "ExifIFDPointer",
      34853: "GPSInfoIFDPointer"
    },
    xu = {
      36864: "ExifVersion",
      40961: "ColorSpace",
      40962: "PixelXDimension",
      40963: "PixelYDimension",
      36867: "DateTimeOriginal",
      33434: "ExposureTime",
      33437: "FNumber",
      34855: "ISOSpeedRatings",
      37377: "ShutterSpeedValue",
      37378: "ApertureValue",
      37383: "MeteringMode",
      37384: "LightSource",
      37385: "Flash",
      37386: "FocalLength",
      41986: "ExposureMode",
      41987: "WhiteBalance",
      41990: "SceneCaptureType",
      41988: "DigitalZoomRatio",
      41992: "Contrast",
      41993: "Saturation",
      41994: "Sharpness"
    },
    Fu = {
      0: "GPSVersionID",
      1: "GPSLatitudeRef",
      2: "GPSLatitude",
      3: "GPSLongitudeRef",
      4: "GPSLongitude"
    },
    Su = { 513: "JPEGInterchangeFormat", 514: "JPEGInterchangeFormatLength" },
    Eu = {
      ColorSpace: { 1: "sRGB", 0: "Uncalibrated" },
      MeteringMode: {
        0: "Unknown",
        1: "Average",
        2: "CenterWeightedAverage",
        3: "Spot",
        4: "MultiSpot",
        5: "Pattern",
        6: "Partial",
        255: "Other"
      },
      LightSource: {
        1: "Daylight",
        2: "Fliorescent",
        3: "Tungsten",
        4: "Flash",
        9: "Fine weather",
        10: "Cloudy weather",
        11: "Shade",
        12: "Daylight fluorescent (D 5700 - 7100K)",
        13: "Day white fluorescent (N 4600 -5400K)",
        14: "Cool white fluorescent (W 3900 - 4500K)",
        15: "White fluorescent (WW 3200 - 3700K)",
        17: "Standard light A",
        18: "Standard light B",
        19: "Standard light C",
        20: "D55",
        21: "D65",
        22: "D75",
        23: "D50",
        24: "ISO studio tungsten",
        255: "Other"
      },
      Flash: {
        0: "Flash did not fire",
        1: "Flash fired",
        5: "Strobe return light not detected",
        7: "Strobe return light detected",
        9: "Flash fired, compulsory flash mode",
        13: "Flash fired, compulsory flash mode, return light not detected",
        15: "Flash fired, compulsory flash mode, return light detected",
        16: "Flash did not fire, compulsory flash mode",
        24: "Flash did not fire, auto mode",
        25: "Flash fired, auto mode",
        29: "Flash fired, auto mode, return light not detected",
        31: "Flash fired, auto mode, return light detected",
        32: "No flash function",
        65: "Flash fired, red-eye reduction mode",
        69: "Flash fired, red-eye reduction mode, return light not detected",
        71: "Flash fired, red-eye reduction mode, return light detected",
        73: "Flash fired, compulsory flash mode, red-eye reduction mode",
        77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected",
        79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected",
        89: "Flash fired, auto mode, red-eye reduction mode",
        93: "Flash fired, auto mode, return light not detected, red-eye reduction mode",
        95: "Flash fired, auto mode, return light detected, red-eye reduction mode"
      },
      ExposureMode: {
        0: "Auto exposure",
        1: "Manual exposure",
        2: "Auto bracket"
      },
      WhiteBalance: { 0: "Auto white balance", 1: "Manual white balance" },
      SceneCaptureType: {
        0: "Standard",
        1: "Landscape",
        2: "Portrait",
        3: "Night scene"
      },
      Contrast: { 0: "Normal", 1: "Soft", 2: "Hard" },
      Saturation: { 0: "Normal", 1: "Low saturation", 2: "High saturation" },
      Sharpness: { 0: "Normal", 1: "Soft", 2: "Hard" },
      GPSLatitudeRef: { 78: "North latitude", 83: "South latitude" },
      GPSLongitudeRef: { 69: "East longitude", 87: "West longitude" }
    },
    Uu = function (n) {
      for (var e = [], t = 2; t + 2 <= n.length(); ) {
        var r = Vo(n, t).toOptional().getOrNull();
        if (null === r) throw new Error("Invalid Exif data.");
        if (65488 <= r && r <= 65495) t += 2;
        else {
          if (65498 === r || 65497 === r) break;
          var o = Vo(n, t + 2)
            .toOptional()
            .getOrNull();
          if (null === o) throw new Error("Invalid Exif data.");
          o = o + 2;
          65505 <= r &&
            r <= 65519 &&
            e.push({
              hex: r,
              name: "APP" + (15 & r),
              start: t,
              length: o,
              segment: n.segment(t, o)
            }),
            (t += o);
        }
      }
      return e;
    },
    Du = function (n, e, t) {
      var r = Zr(n),
        o = Qr(n),
        u = e / r,
        r = t / o,
        o = !1;
      (u < 0.5 || 2 < u) && ((u = u < 0.5 ? 0.5 : 2), (o = !0)),
        (r < 0.5 || 2 < r) && ((r = r < 0.5 ? 0.5 : 2), (o = !0));
      r = _u(n, u, r);
      return o
        ? r.then(function (n) {
            return Du(n, e, t);
          })
        : r;
    },
    _u = function (i, a, f) {
      return new Eo(function (n) {
        var e = Zr(i),
          t = Qr(i),
          r = Math.floor(e * a),
          o = Math.floor(t * f),
          u = Yr(r, o);
        Fo(u).drawImage(i, 0, 0, e, t, 0, 0, r, o), n(u);
      });
    },
    Ru = function (n, e, t) {
      var r = Yr(n.width, n.height),
        o = Fo(r),
        u = 0,
        i = 0;
      return (
        (90 !== (t = t < 0 ? 360 + t : t) && 270 !== t) ||
          So(r, r.height, r.width),
        (90 !== t && 180 !== t) || (u = r.width),
        (270 !== t && 180 !== t) || (i = r.height),
        o.translate(u, i),
        o.rotate((t * Math.PI) / 180),
        o.drawImage(n, 0, 0),
        Ao(r, e)
      );
    },
    Pu = Io,
    ku = ["image/jpeg", "image/png", "image/gif"],
    Iu = Ft([_t("filetypes", [], St(Qt))]),
    ju = Ft([
      _t("path", "/", Qt),
      n("name"),
      $t((Tu = "blob"), Tu, gt(), Yt()),
      _t("onprogress", m, er),
      $t("max_image_dimension", "maxImageDimension", vt(), Zt)
    ]);
  tinymce.PluginManager.add("tinydrive", function (n, e) {
    var t,
      r,
      o,
      u,
      i,
      a,
      f,
      c,
      s = d(D.none()),
      l = Xr(n, s),
      s =
        ((r = {}),
        (t = n).on("PreInit", function () {
          t.editorUpload.addFilter &&
            t.editorUpload.addFilter(function (n) {
              return !1 === r.hasOwnProperty(n.src);
            });
        }),
        function (n) {
          r[n] = !0;
        });
    return (
      pu(n, l, s),
      Wr(n, e, l),
      Kr(n, e, l),
      (u = e),
      (i = l),
      (s = (o = n).settings).file_picker_callback ||
        (s.file_picker_callback = function (t, n, e) {
          Vr(o, u, i, e).get(function (n) {
            O(n).each(function (e) {
              e.url.each(function (n) {
                return t(n, { title: e.name, text: e.name });
              });
            });
          });
        }),
      (a = n),
      (f = e),
      (c = l),
      {
        pick: function (n) {
          return Me(bu(a, f, c, n, !0));
        },
        browse: function (n) {
          return Me(bu(a, f, c, n, !1).mapResult(m));
        },
        upload: function (n) {
          return Me(wu(a, c, n));
        }
      }
    );
  });
})();
